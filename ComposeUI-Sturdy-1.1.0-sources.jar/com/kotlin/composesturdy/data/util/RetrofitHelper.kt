@file:Suppress("unused")

package com.kotlin.composesturdy.data.util

import android.content.Context
import com.kotlin.sturdy.data.util.RetrofitHelperRoot
import com.kotlin.sturdy.data.util.apiResponseRoot
import com.kotlin.sturdy.data.util.interceptRoot
import com.kotlin.sturdy.data.util.manualDecodeRoot
import com.kotlin.sturdy.data.util.parseDecodeRoot
import com.kotlin.sturdy.data.util.safeApiCallCacheRoot
import com.kotlin.sturdy.data.util.safeApiCallRoot
import kotlinx.serialization.json.Json
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Response
import retrofit2.Retrofit

/**
 * Helper object for creating and configuring Retrofit instances with OkHttp clients.
 * Provides JSON serialization, logging, caching, and connection management.
 */
object RetrofitHelper {

    /**
     * Interceptor for adding authentication headers to requests.
     * Usage: Add this interceptor to your OkHttp client and provide a token provider function.
     */
    val json = Json {
        ignoreUnknownKeys = true      // Handle new API fields gracefully
        encodeDefaults = true         // Don't send default values (save bandwidth)
        isLenient = true               // Be lenient with parsing edge cases
        coerceInputValues = true       // Handle invalid enum values by using defaults
    }

    /**
     * Default cache size for the OkHttp client (10 MB).
     */
    const val CACHE_SIZE = RetrofitHelperRoot.CACHE_SIZE

    /**
     * OkHttp client for making network requests.
     * Includes logging, default headers, timeouts, and connection management.
     * config: The configuration for the OkHttp client.
     * return: An OkHttpClient.Builder instance with the specified configuration.
     */
    inline val client: (config: OkHttpClientConfig) -> OkHttpClient.Builder
        get() = { config ->
            RetrofitHelperRoot.client(
                config.connectTimeoutSecond,
                config.readTimeoutSecond,
                config.writeTimeoutSecond,
                config.maxRequests,
                config.maxRequestsPerHost,
                config.maxIdleConnectionsMinutesAtPool,
                config.keepAliveDurationMinutesAtPool
            )
        }

    /**
     * Creates a Retrofit instance with the specified base URL and OkHttp client.
     * @param baseUrl The base URL for the Retrofit instance.
     * @param client The OkHttp client to use (defaults to the configured client).
     * @param validateEagerly Whether to validate Retrofit interfaces eagerly.
     * @return A configured Retrofit instance.
     */
    fun retrofit(
        baseUrl: String,
        client: OkHttpClient = this.client(OkHttpClientConfig()).build(),
        validateEagerly: Boolean = false,
    ): Retrofit = RetrofitHelperRoot.retrofit(baseUrl, client, validateEagerly)

    /**
     * Provides an OkHttp client with caching enabled.
     * config: The configuration for the OkHttp client.
     * cacheSize: The cache size in bytes.
     * return: An OkHttpClient instance with caching configured.
     */
    inline val Context.clientCache: (config: OkHttpClientConfig, cacheSize: Long) -> OkHttpClient
        get() = { config, cacheSize ->
            RetrofitHelperRoot.run {
                this@clientCache.clientCache(
                    cacheSize,
                config.connectTimeoutSecond,
                config.readTimeoutSecond,
                config.writeTimeoutSecond,
                config.maxRequests,
                config.maxRequestsPerHost,
                config.maxIdleConnectionsMinutesAtPool,
                config.keepAliveDurationMinutesAtPool
                )
            }
        }

    /**
     * Clears the OkHttp client's cache.
     * @param cacheSize The cache size in bytes (used if the cache needs to be recreated).
     */
    fun Context.clearClientCache(cacheSize: Long = CACHE_SIZE) = RetrofitHelperRoot.apply { clearClientCache(cacheSize) }
}

data class OkHttpClientConfig(
    val connectTimeoutSecond: Long = 15L,
    val readTimeoutSecond: Long = 30L,
    val writeTimeoutSecond: Long = 30L,
    val maxRequests: Int = 10,
    val maxRequestsPerHost: Int = 4,
    val maxIdleConnectionsMinutesAtPool: Int = 5,
    val keepAliveDurationMinutesAtPool: Long = 5,
)

/**
 * Interceptor for adding authorization headers to requests.
 */
class AuthInterceptor(private val tokenProvider: () -> String?) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): okhttp3.Response {
        return chain.interceptRoot(tokenProvider)
    }
}


/**
 * Extension function for making API calls with Retrofit and handling responses.
 * @param failed Callback invoked when the API call fails.
 * @param invoke Callback invoked when the API call succeeds.
 */
inline fun <reified T> Call<T>.apiResponse(
    crossinline failed: (String) -> Unit = {},
    crossinline invoke: (T) -> Unit
) = apiResponseRoot(failed = failed, invoke = invoke)

/**
 * Extension function for parsing and decoding a JSON string into a Kotlin object.
 * @return The decoded object of type T.
 */
inline fun <reified T> String.parseDecode(): T = parseDecodeRoot<T>()

/**
 * Extension function for making safe API calls with caching support.
 * @param okHttpClient The OkHttpClient instance used for network requests.
 * @param failed Callback invoked when the API call fails.
 * @param onResult Callback invoked when the API call succeeds, with a flag indicating if the result is from cache.
 */
suspend inline fun <reified T> Call<T>.safeApiCallCache(
    okHttpClient: OkHttpClient,
    crossinline failed: (String) -> Unit = {},
    crossinline onResult: (T, isCached: Boolean) -> Unit
) = safeApiCallCacheRoot(okHttpClient, failed, onResult)

/**
 * Safely executes an API call and handles the response.
 * @param call The suspend function representing the API call.
 * @param failed Callback invoked when the API call fails.
 * @param invoke Callback invoked when the API call succeeds.
 */
suspend fun <T> safeApiCall(
    call: suspend () -> Response<T>,         // trailing lambda → clean call-site
    failed: (String) -> Unit = {},
    invoke: (T) -> Unit,
) = safeApiCallRoot(call = call, failed = failed, invoke = invoke)

/**
 * Safely executes an API call and returns the response body if successful.
 * @param call The suspend function representing the API call.
 * @return The response body of type T if the call is successful, null otherwise.
 */
suspend fun <T> safeApiCall(
    call: suspend () -> Response<T>,         // trailing lambda → clean call-site
): T? = safeApiCallRoot(call)

/**
 * Extension function for manually decoding a JSONObject into a Kotlin object of type T.
 * @return The decoded object of type T if successful, null otherwise.
 */
inline fun <reified T> JSONObject.manualDecode(): T? = manualDecodeRoot()