@file:Suppress("unused")

package com.kotlin.composesturdy.data.util

import com.kotlin.sturdy.data.util.BaseCloudImpRoot
import io.ktor.client.HttpClient
import io.ktor.client.plugins.websocket.DefaultClientWebSocketSession
import io.ktor.client.request.HttpRequestBuilder
import io.ktor.client.request.forms.MultiPartFormDataContent
import io.ktor.http.HeadersBuilder

/**
 * Base implementation for HTTP, WebSocket, and optional cached cloud operations.
 *
 * Provides reusable wrappers for REST calls, multipart uploads, and streaming updates,
 * while optionally exposing URL-based manual cache reads before network requests.
 *
 * @property client Main HTTP client for standard requests.
 * @property clientSocket HTTP client configured for WebSocket sessions.
 * @property clientCache Optional HTTP client configured with cache support.
 * @property cacheDir Optional cache directory used by [com.kotlin.composesturdy.data.util.CloudSturdy] manual cache helpers.
 *
 * @see com.kotlin.composesturdy.data.util.CloudSturdy.baseHttpClient
 * @see com.kotlin.composesturdy.data.util.CloudSturdy.baseSocketClient
 * @see com.kotlin.composesturdy.data.util.CloudSturdy.baseHttpClientCached
 */
abstract class BaseCloudImp(val client: HttpClient, val clientSocket: HttpClient, val clientCache: HttpClient? = null, val cacheDir: java.io.File? = null) {

    /**
     * Creates a cloud repository from a prebuilt [com.kotlin.composesturdy.data.util.CloudSturdyConfig].
     *
     * @param config Contains HTTP, WebSocket, and optional cache client setup.
     */
    constructor(config: CloudSturdyConfig) : this(config.client, config.socket, config.clientCache?.client, config.clientCache?.cacheDir)

    @PublishedApi
    internal val root: BaseCloudImpRoot = BaseCloudImpRoot(client, clientSocket, clientCache, cacheDir)


    /** Active WebSocket session for real-time communication */
    val session: DefaultClientWebSocketSession? = root.session


    /**
     * Performs a GET request and deserializes the response.
     *
     * @param url The endpoint URL
     * @param block Optional request configuration
     * @return Deserialized response object if successful, null otherwise
     */
    suspend inline fun <reified S: BaseObject> get(url: String, noinline block: HttpRequestBuilder.() -> Unit = {}): S? {
        return root.get(url, block)
    }

    /**
     * Performs a GET request and emits cached data first when available.
     *
     * Cache lookup is URL-based. If a cached payload exists, [cacheResponse] is invoked
     * before the network request executes.
     *
     * @param url Endpoint URL used for cache lookup and request execution.
     * @param block Optional request customization.
     * @param cacheResponse Callback receiving cached value before network response.
     * @return Parsed network response object, or null on failure.
     */
    suspend inline fun <reified S: BaseObject> getCache(url: String, noinline block: HttpRequestBuilder.() -> Unit = {}, cacheResponse: (S?) -> Unit): S? {
        return root.getCache(url, block, cacheResponse)
    }


    /**
     * Performs a POST request and returns the same object on success.
     *
     * @param url The endpoint URL
     * @param body The request body object
     * @param block Optional headers configuration
     * @return Deserialized response object if successful, null otherwise
     */
    suspend inline fun <reified Q : BaseObject, reified S : BaseObject> post(url: String, body: Q?, noinline block: HeadersBuilder.() -> Unit = {}): S? {
        return root.post(url, body, block)
    }

    /**
     * Performs a POST request and emits cached data first when available.
     *
     * Cache lookup is URL-based. If a cached payload exists, [cacheResponse] is invoked
     * before the network request executes.
     *
     * @param url Endpoint URL used for cache lookup and request execution.
     * @param body Request body serialized as JSON.
     * @param block Optional header customization.
     * @param cacheResponse Callback receiving cached value before network response.
     * @return Parsed network response object, or null on failure.
     */
    suspend inline fun <reified Q : BaseObject, reified S : BaseObject> postCache(url: String, body: Q?, noinline block: HeadersBuilder.() -> Unit = {}, cacheResponse: (S?) -> Unit): S? {
        return root.postCache(url, body, block, cacheResponse)
    }


    /**
     * Updates a resource via PATCH request and returns the updated object.
     *
     * @param url The endpoint URL
     * @param block Optional request configuration
     * @return Deserialized updated object or null if request fails
     */
    suspend inline fun <reified Q: BaseObject, reified S: BaseObject> patch(url: String, body: Q?, noinline block: HttpRequestBuilder.() -> Unit = {}): S? {
        return root.patch(url, body, block)
    }

    /**
     * Updates a resource via PUT request.
     *
     * @param url The endpoint URL
     * @param body The object to update
     * @param block Header configuration
     * @return The body object or null if request fails
     */
    suspend inline fun <reified Q: BaseObject, reified S: BaseObject> put(url: String, body: Q?, noinline block: HeadersBuilder.() -> Unit): S? {
        return root.put(url, body, block)
    }

    /**
     * Deletes a resource via DELETE request.
     *
     * @param url The endpoint URL
     * @param block Optional header configuration
     * @return The body object or null if request fails
     */
    suspend inline fun <reified S: BaseObject> delete(url: String, noinline block: HeadersBuilder.() -> Unit = {}): S? {
        return root.delete(url, block)
    }

    /**
     * Uploads multipart form data containing JSON and file.
     *
     * @param url The endpoint URL
     * @param body Object containing JSON data and file information
     * @param block Optional header configuration
     * @return The body object or null if request fails
     */
    suspend inline fun <reified Q : BaseObjectMultiPart, reified S: BaseObject> postMultiPart(
        url: String,
        body: Q,
        noinline block: HeadersBuilder.() -> Unit = {}
    ): S? {
        return root.postMultiPart(url, body, block)
    }


    /**
     * Uploads multipart form data containing JSON and file.
     *
     * @param url The endpoint URL
     * @param body Object containing JSON data and file information
     * @param block Optional header configuration
     * @return The body object or null if request fails
     */
    suspend inline fun <reified S : BaseObject> postMultiPart(
        url: String,
        body: MultiPartFormDataContent,
        noinline block: HeadersBuilder.() -> Unit = {}
    ): S? {
        return root.postMultiPart(url, body, block)
    }

    /**
     * Establishes a WebSocket connection for real-time data streaming.
     * Closes any existing session before creating a new one.
     *
     * @param url The WebSocket endpoint URL
     * @param request Request configuration
     * @param invoke Callback invoked for each received message
     */
    suspend inline fun <reified T> startObserving(url: String, noinline request: HttpRequestBuilder.() -> Unit, crossinline invoke: (T) -> Unit) {
        root.startObserving(url, request, invoke)
    }

    /**
     * Uploads a file directly via PUT request with custom headers.
     *
     * @param url The upload endpoint URL
     * @param file The file data to upload
     * @param headers Optional custom headers (e.g., authorization, content-type overrides)
     * @return The URL on success or null if upload fails
     */
    suspend fun <T: BaseFileData> uploadFile(url: String, file: T, headers: Map<String, String> = emptyMap()): String? {
        return root.uploadFile(url, file, headers)
    }
}
