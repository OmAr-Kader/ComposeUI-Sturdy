@file:Suppress("unused")

package com.kotlin.composesturdy.data.util

import androidx.compose.runtime.Immutable
import com.kotlin.composesturdy.data.util.CloudSturdy.baseHttpClient
import com.kotlin.composesturdy.data.util.CloudSturdy.baseHttpClientCached
import com.kotlin.composesturdy.data.util.CloudSturdy.baseSocketClient
import com.kotlin.sturdy.data.util.CloudSturdyCacheRoot
import com.kotlin.sturdy.data.util.CloudSturdyConfigRoot
import com.kotlin.sturdy.data.util.CloudSturdyInternal
import io.ktor.client.HttpClient
import io.ktor.client.plugins.HttpTimeoutConfig
import io.ktor.client.plugins.logging.LogLevel
import io.ktor.http.ContentType
import io.ktor.http.HeadersBuilder
import io.ktor.http.HttpHeaders
import io.ktor.util.appendIfNameAbsent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import java.io.File

/**
 * Central factory for configured Ktor clients and URL-based manual JSON caching.
 *
 * Use this object to create HTTP/WebSocket clients with shared defaults and to
 * read/write cached JSON payloads keyed by normalized URL.
 */
object CloudSturdy {

    @Deprecated("Not used in current implementations, may be removed in future versions.")
    const val CLOUD_SUCCESS: Int = 1

    @Deprecated("Not used in current implementations, may be removed in future versions.")
    const val CLOUD_FAILED: Int = -1

    /** Shared JSON configuration used by all CloudSturdy clients. */
    @JvmStatic
    val json = Json {
        ignoreUnknownKeys = true      // Handle new API fields gracefully
        encodeDefaults = true         // Include default values for stable request contracts
        isLenient = true               // Be lenient with parsing edge cases
        coerceInputValues = true       // Handle invalid enum values by using defaults
        useArrayPolymorphism = false   // Use class discriminator for polymorphism
        prettyPrint = false            // Pretty print in debug mode for logging
    }

    /** Default request headers applied by generated clients. */
    inline val baseConfigHeader : HeadersBuilder.() -> Unit
        get() = {
            appendIfNameAbsent(
                HttpHeaders.AcceptLanguage,
                "en"
            )
        }

    ////////////////////////////////////////////// HTTP Client Configurations //////////////////////////////////////////

    /** Default timeout profile for standard HTTP requests. */
    inline val baseConfigTimeout: HttpTimeoutConfig.() -> Unit
        get() = {
            /**
             * Whole request timeout
             */
            requestTimeoutMillis = 30_000

            /**
             * TCP connect timeout
             */
            connectTimeoutMillis = 15_000

            /**
             * Socket read/write timeout
             */
            socketTimeoutMillis = 30_000
        }


    /**
     * Deprecated compatibility method kept for older integrations.
     *
     * @deprecated Use [baseHttpClient] or [baseHttpClientCached].
     */
    @Deprecated("Use baseHttpClient() or baseHttpClientCached() to create configured HttpClient instances.")
    fun fetchBaseHttpClient(isDebug: Boolean): HttpClient {
        throw UnsupportedOperationException("Deprecated, Use baseHttpClient() or baseHttpClientCached() to create configured HttpClient instances.")
    }

    /**
     * Deprecated compatibility method kept for older integrations.
     *
     * @deprecated Use [baseSocketClient].
     */
    @Deprecated("Use baseSocketClient() to create configured HttpClient instances.")
    fun fetchBaseSocketClient(isDebug: Boolean): HttpClient {
        throw UnsupportedOperationException("Deprecated, Use baseSocketClient() to create configured HttpClient instances.")
    }

    /**
     * Creates an HTTP client configured with JSON content negotiation.
     *
     * @param isDebug When true, enables request/response body logging
     * @param baseUrl Optional base URL applied to outgoing requests
     * @param debugLevel Logging verbosity used when [isDebug] is true
     * @param params Optional default query parameters added to each request
     * @param block Default headers configuration
     * @param configTimeout Timeout configuration for request/connect/socket operations
     * @return Configured HttpClient instance for standard HTTP operations
     */
    fun baseHttpClient(
        isDebug: Boolean,
        baseUrl: String? = null,
        debugLevel: LogLevel = LogLevel.BODY,
        params: Set<Pair<String, String>> = emptySet(),
        block: HeadersBuilder.() -> Unit = baseConfigHeader,
        configTimeout: HttpTimeoutConfig.() -> Unit = baseConfigTimeout
    ): HttpClient {
        return CloudSturdyInternal.baseHttpClient(
            isDebug,
            baseUrl,
            debugLevel,
            params,
            block,
            configTimeout
        )
    }

    //////////////////////////////////////////// WebSocket Client Configurations //////////////////////////////////////////

    /** Default timeout profile for WebSocket-focused clients. */
    inline val baseConfigSocketTimeout: HttpTimeoutConfig.() -> Unit
        get() = {

            /**
             * IMPORTANT:
             * WebSockets should NOT use request timeout
             * or connection dies unexpectedly
             */
            requestTimeoutMillis = Long.MAX_VALUE

            connectTimeoutMillis = 15_000

            socketTimeoutMillis = Long.MAX_VALUE
        }

    /**
     * Creates an HTTP client configured with WebSocket and JSON support.
     *
     * @param isDebug When true, enables request/response body logging
     * @param baseUrl Optional base URL applied to outgoing requests
     * @param debugLevel Logging verbosity used when [isDebug] is true
     * @param params Optional default query parameters added to each request
     * @param block Default headers configuration
     * @param configTimeout Timeout configuration tuned for long-lived sockets
     * @return Configured HttpClient instance with WebSocket capabilities
     */
    fun baseSocketClient(
        isDebug: Boolean,
        baseUrl: String? = null,
        debugLevel: LogLevel = LogLevel.BODY,
        params: Set<Pair<String, String>> = emptySet(),
        block: HeadersBuilder.() -> Unit = baseConfigHeader,
        configTimeout: HttpTimeoutConfig.() -> Unit = baseConfigSocketTimeout
    ): HttpClient {
        return CloudSturdyInternal.baseSocketClient(
            isDebug,
            baseUrl,
            debugLevel,
            params,
            block,
            configTimeout
        )
    }

    ////////////////////////////////////////////// HTTP Client with Manual Caching //////////////////////////////////////////

    /**
     * Reads cached JSON for the provided URL.
     *
     * Cache identity is URL-based, so GET/POST/etc for the same URL share one cache entry.
     *
     * @param cacheDir Root cache directory used for manual cache storage.
     * @param url URL key used to locate cached payload.
     * @return Raw cached JSON or null if no cache exists/read fails.
     */
    @JvmStatic
    suspend fun getManualCacheByUrl(cacheDir: File?, url: String): String? = withContext(Dispatchers.IO) {
        CloudSturdyInternal.getManualCacheObjectByUrl(cacheDir, url)
    }

    /**
     * Writes raw JSON in manual cache for the provided URL.
     *
     * Cache identity is URL-based, so writing POST/GET to same URL overwrites previous value.
     *
     * @param cacheDir Root cache directory used for manual cache storage.
     * @param url URL key used to locate cache entry.
     * @param rawJson Raw JSON response to persist.
     */
    @JvmStatic
    fun setManualCacheByUrl(cacheDir: File?, url: String, rawJson: String) {
        CloudSturdyInternal.setManualCacheByUrl(cacheDir, url, rawJson)
    }

    /**
     * Helper for reading and decoding a cached JSON payload by URL.
     *
     * @param cacheDir Root cache directory used for manual cache storage.
     * @param url URL key used to locate cached payload.
     * @return Decoded object or null when cache is missing/invalid.
     */
    suspend inline fun <reified T> getManualCacheObjectByUrl(cacheDir: File?, url: String): T? {
        return CloudSturdyInternal.getManualCacheObjectByUrl<T>(cacheDir, url)
    }


    /**
     * Creates an HTTP client with OkHttp engine and manual JSON caching.
     *
     * The returned client applies both OkHttp cache and URL-based manual JSON cache
     *
     * @param isDebug When true, enables request/response body logging
     * @param cacheDir Root directory used for OkHttp and manual cache files
     * @param baseUrl Optional base URL applied to outgoing requests
     * @param debugLevel Logging verbosity used when [isDebug] is true
     * @param params Optional default query parameters added to each request
     * @param block Default headers configuration
     * @param configTimeout Timeout configuration for request/connect/socket operations
     * @return CloudSturdyCache containing the configured HttpClient and cache directory
     */
    fun baseHttpClientCached(
        isDebug: Boolean,
        cacheDir: File,
        baseUrl: String? = null,
        debugLevel: LogLevel = LogLevel.BODY,
        params: Set<Pair<String, String>> = emptySet(),
        block: HeadersBuilder.() -> Unit = baseConfigHeader,
        configTimeout: HttpTimeoutConfig.() -> Unit = baseConfigTimeout
    ): CloudSturdyCache {
        return CloudSturdyInternal.baseHttpClientCached(
            isDebug,
            cacheDir,
            baseUrl,
            debugLevel,
            params,
            block,
            configTimeout
        ).toPublic()
    }
}

@Immutable
data class CloudSturdyConfig(
    val client: HttpClient,
    val socket: HttpClient,
    val clientCache: CloudSturdyCache? = null,
)

@Immutable
data class CloudSturdyCache(
    val client: HttpClient,
    val cacheDir: File
)

/**
 * Base class for objects that can be serialized to JSON.
 *
 * Provides standard JSON serialization functionality for network requests
 * and data transfer operations.
 *
 * Example
 *
 * ````
 * @Serializable
 * data class User(val id: String, val name: String): BaseObject() {
 *     override fun json(): JsonObject = CloudSturdy.json.encodeToJsonElement(this).jsonObject
 * }
 * ````
 */


typealias BaseObject = () -> JsonObject

/**
 * Base class for file data without additional JSON metadata.
 *
 * Represents raw file content for upload or download operations.
 */


/**
 * Base class for multipart requests containing both JSON data and file content.
 *
 * Used for operations that require sending structured data along with file uploads.
 */
interface BaseObjectMultiPart  {

    /**
     * Converts this object's metadata to a JsonObject.
     *
     * @return JsonObject containing the object's structured data
     */
    fun json(): JsonObject


    /**
     * Retrieves the file content as a byte array.
     *
     * @return ByteArray containing the file data
     */
    fun bytes(): ByteArray

    /**
     * Specifies the MIME type of the file.
     *
     * @return ContentType of the file being uploaded
     */
    fun fileType(): ContentType

    /**
     * Provides the name of the file.
     *
     * @return String containing the file name
     */
    fun fileName(): String

    /**
     * Converts this object's metadata to a JSON string.
     *
     * @return String representation of the JSON object
     */
    fun jsonStr(): String {
        return json().toString()
    }
}



/**
 * Base class for file data without additional JSON metadata.
 *
 * Represents raw file content for upload or download operations.
 */
interface BaseFileData {

    /**
     * Retrieves the file content as a byte array.
     *
     * @return ByteArray containing the file data
     */
    fun bytes(): ByteArray
    /**
     * Specifies the MIME type of the file.
     *
     * @return ContentType of the file
     */
    fun fileType(): ContentType

    /**
     * Provides the name of the file.
     *
     * @return String containing the file name
     */
    fun fileName(): String
}


////////////////////////// INTERNAL MAPPINGS - DO NOT USE OUTSIDE THIS MODULE //////////////////////////

@PublishedApi
internal fun CloudSturdyConfig.toRoot(): CloudSturdyConfigRoot = CloudSturdyConfigRoot(
    client = client,
    socket = socket,
    clientCache = clientCache?.toRoot()
)

@PublishedApi
internal fun CloudSturdyCache.toRoot(): CloudSturdyCacheRoot = CloudSturdyCacheRoot(
    client = client,
    cacheDir = cacheDir
)

@PublishedApi
internal fun CloudSturdyConfigRoot.toPublic(): CloudSturdyConfig = CloudSturdyConfig(
    client = client,
    socket = socket,
    clientCache = clientCache?.toPublic()
)

@PublishedApi
internal fun CloudSturdyCacheRoot.toPublic(): CloudSturdyCache = CloudSturdyCache(
    client = client,
    cacheDir = cacheDir
)
