package com.kotlin.composesturdy.data.util

import androidx.compose.runtime.Immutable

@Immutable
sealed class RequestState<out T> {
    @Immutable
    object Idle : RequestState<Nothing>()
    @Immutable
    object Loading : RequestState<Nothing>()
    @Immutable
    data class Error(val message: String) : RequestState<Nothing>()
    @Immutable
    data class Success<T>(val data: T) : RequestState<T>()
}