@file:Suppress("unused")

package com.kotlin.composesturdy.global.ui

import androidx.compose.animation.core.Transition
import androidx.compose.runtime.Composable
import com.kotlin.sturdy.global.ui.FabItem
import com.kotlin.sturdy.global.ui.MultiFabState
import com.kotlin.sturdy.global.ui.MultiFloatingActionButtonRoot
import com.kotlin.sturdy.global.ui.MultiFloatingTheme
import com.kotlin.sturdy.global.ui.SmallFloatingActionButtonRowRoot

/**
 * A multi-option floating action button that expands to reveal additional action buttons.
 * When expanded, displays a curved background overlay and animates child buttons into view.
 * Based on reference: https://github.com/khambhaytajaydip/MultipleFloatingActionButton
 *
 * @param items List of action items to display when expanded
 * @param onClick Callback invoked when an item is clicked, receives the item's index
 */
@Composable
fun MultiFloatingActionButton(
    items: List<FabItem>,
    theme: MultiFloatingTheme,
    onClick: (Int) -> Unit,
) = MultiFloatingActionButtonRoot(items, theme, onClick)

/**
 * An individual action button row within the multi-floating action button.
 * Handles the expand/collapse animation for a single item.
 *
 * @param item The FAB item containing icon, label, and color
 * @param index The position index of this item in the list
 * @param stateTransition Transition state for coordinating animations
 * @param onClick Callback invoked when this item is clicked, receives the item's index
 */
@Composable
fun SmallFloatingActionButtonRow(
    item: FabItem,
    index: Int,
    theme: MultiFloatingTheme,
    stateTransition: Transition<MultiFabState>,
    onClick: (Int) -> Unit,
) = SmallFloatingActionButtonRowRoot(item, index, theme, stateTransition, onClick)