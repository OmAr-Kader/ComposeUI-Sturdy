@file:Suppress("unused")

package com.kotlin.composesturdy.global.ui

import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.kotlin.sturdy.global.ui.backDarkRoot
import com.kotlin.sturdy.global.ui.backDarkSecRoot
import com.kotlin.sturdy.global.ui.backDarkThrRoot
import com.kotlin.sturdy.global.ui.backGreyTransRoot
import com.kotlin.sturdy.global.ui.darkenRoot
import com.kotlin.sturdy.global.ui.darkerRoot
import com.kotlin.sturdy.global.ui.errorRoot
import com.kotlin.sturdy.global.ui.getGradientFromBaseColorRoot
import com.kotlin.sturdy.global.ui.lightenRoot
import com.kotlin.sturdy.global.ui.margeRoot
import com.kotlin.sturdy.global.ui.outlinedDisabledStyleRoot
import com.kotlin.sturdy.global.ui.outlinedTextFieldStyleRoot
import com.kotlin.sturdy.global.ui.rateColorRoot
import com.kotlin.sturdy.global.ui.shadowColorRoot
import com.kotlin.sturdy.global.ui.textColorRoot
import com.kotlin.sturdy.global.ui.textGrayColorRoot
import com.kotlin.sturdy.global.ui.textHintColorRoot

/**
 * Returns a darker version of this color by blending it with black.
 * The color is darkened by 15% by default.
 */
@get:Composable
@get:ReadOnlyComposable
val Color.darker: Color
    get() = darkerRoot

/**
 * Returns a darker version of this color by blending it with black.
 *
 * @param f The darkening factor (0.0 to 1.0), defaults to 0.15 (15% darker)
 * @return A new color that is darker than the original
 */
@Composable
@ReadOnlyComposable
fun Color.darker(f: Float = 0.15F): Color = darkerRoot(f)

/**
 * Blends this color with another color using a specified ratio.
 *
 * @param topColor The color to blend with
 * @param ratio The blend ratio (0.0 = original color, 1.0 = top color), defaults to 0.5
 * @return A new color that is a blend of both colors
 */
fun Color.marge(topColor: Color, ratio: Float = 0.5f): Color = margeRoot(topColor, ratio)

/**
 * Lightens this color by moving RGB values toward white.
 *
 * @param factor The lightening factor (0.0 = no change, 1.0 = white)
 * @return A new color that is lighter than the original
 */
fun Color.lighten(factor: Float): Color = lightenRoot(factor)

/**
 * Darkens the color by reducing RGB values toward black.
 *
 * @param factor The darkening intensity (0.0 to 1.0), where higher values produce darker colors.
 * @return A new Color instance with darkened RGB values, preserving the original alpha.
 */
fun Color.darken(factor: Float): Color = darkenRoot(factor)

/**
 * Creates a linear gradient brush from this color to the specified second color.
 *
 * @param second The ending color of the gradient.
 * @return A linear gradient Brush transitioning from this color to the second color.
 */
fun Color.getGradientFromBaseColor(second: Color): Brush = getGradientFromBaseColorRoot(second)

/**
 * Returns styled TextFieldColors for an outlined text field with focus states.
 *
 * @return TextFieldColors configured with secondary theme color for focus and error styling.
 */
@Composable
fun Boolean.outlinedTextFieldStyle(): TextFieldColors = outlinedTextFieldStyleRoot()

/**
 * Returns styled TextFieldColors for a disabled outlined text field.
 *
 * @param isError Whether to apply error styling to the disabled field.
 * @return TextFieldColors configured for disabled state with optional error indication.
 */
@Composable
fun Boolean.outlinedDisabledStyle(isError: Boolean): TextFieldColors = outlinedDisabledStyleRoot(isError)

/**
 * A semi-transparent black color used for shadow effects.
 * @return Black color with 50 alpha transparency.
 */
@get:Composable
@get:ReadOnlyComposable
val shadowColor: Color
    get() = shadowColorRoot

/**
 * Generates a color based on a rating value, blending from yellow (high) to dark gray (low).
 * @param rate The rating value, typically on a scale of 0.0 to 5.0.
 * @return A blended color where 5.0 is yellow and 0.0 is dark gray.
 */
@Composable
@ReadOnlyComposable
fun rateColor(rate: Double): Color = rateColorRoot(rate)

/**
 * Primary background color that adapts to dark mode.
 * @receiver isDarkMode - true for dark theme, false for light theme.
 * @return Dark gray (#1F1F1F) in dark mode, white in light mode.
 */
@get:Composable
@get:ReadOnlyComposable
val Boolean.backDark: Color
    get() = backDarkRoot

/**
 * Secondary background color that adapts to dark mode.
 * @receiver isDarkMode - true for dark theme, false for light theme.
 * @return Medium gray (#3D3D3D) in dark mode, light gray (#C9C9C9) in light mode.
 */
@get:Composable
@get:ReadOnlyComposable
val Boolean.backDarkSec: Color
    get() = backDarkSecRoot

/**
 * Tertiary background color that adapts to dark mode.
 * @receiver isDarkMode - true for dark theme, false for light theme.
 * @return Light gray (#646464) in dark mode, gray (#ACACAC) in light mode.
 */
@get:Composable
@get:ReadOnlyComposable
val Boolean.backDarkThr: Color
    get() = backDarkThrRoot

/**
 * Translucent background overlay color that adapts to dark mode.
 * @receiver isDarkMode - true for dark theme, false for light theme.
 * @return Semi-transparent dark gray in dark mode, semi-transparent light gray in light mode.
 */
@get:Composable
@get:ReadOnlyComposable
val Boolean.backGreyTrans: Color
    get() = backGreyTransRoot

/**
 * Primary text color that adapts to dark mode.
 * @receiver isDarkMode - true for dark theme, false for light theme.
 * @return White in dark mode, black in light mode.
 */
@get:Composable
@get:ReadOnlyComposable
val Boolean.textColor: Color
    get() = textColorRoot

/**
 * Secondary gray text color that adapts to dark mode.
 * @receiver isDarkMode - true for dark theme, false for light theme.
 * @return Light gray in dark mode, dark gray in light mode.
 */
@get:Composable
@get:ReadOnlyComposable
val Boolean.textGrayColor: Color
    get() = textGrayColorRoot

/**
 * Error state color that adapts to dark mode.
 * @receiver isDarkMode - true for dark theme, false for light theme.
 * @return Bright red (#FF1515) in dark mode, darker red (#9B0000) in light mode.
 */
@get:Composable
@get:ReadOnlyComposable
val Boolean.error: Color
    get() = errorRoot

/**
 * Hint/placeholder text color that adapts to dark mode.
 * @receiver isDarkMode - true for dark theme, false for light theme.
 * @return Light gray (#AFAFAF) in dark mode, medium gray (#505050) in light mode.
 */
@get:Composable
@get:ReadOnlyComposable
val Boolean.textHintColor: Color
    get() = textHintColorRoot
