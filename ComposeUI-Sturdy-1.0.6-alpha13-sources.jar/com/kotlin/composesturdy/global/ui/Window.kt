@file:Suppress("unused", "DEPRECATION")

package com.kotlin.composesturdy.global.ui

import android.app.Activity
import android.os.Build
import android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
import android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
import android.view.View.SYSTEM_UI_FLAG_IMMERSIVE
import android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
import android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
import android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
import android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
import android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
import android.view.Window
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager.LayoutParams.FLAGS_CHANGED
import android.view.WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
import android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN
import android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
import android.view.WindowManager.LayoutParams.FLAG_SECURE
import android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
import android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
import android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
import android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
import android.view.WindowManager.LayoutParams.TYPE_KEYGUARD_DIALOG
import android.view.WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
import androidx.activity.compose.LocalActivity
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.core.view.WindowCompat
import com.kotlin.sturdy.global.ui.baseActivityIgnoreStatusBarSpaceRoot
import com.kotlin.sturdy.global.ui.hideAllSystemUIRoot
import com.kotlin.sturdy.global.ui.KeepScreenOnAndRemoveAtDisposeRoot
import com.kotlin.sturdy.global.ui.keepScreenOnRoot
import com.kotlin.sturdy.global.ui.lockAlarmFiredScreenRoot
import com.kotlin.sturdy.global.ui.lockMusicScreenRoot
import com.kotlin.sturdy.global.ui.removeKeepScreenOnRoot
import com.kotlin.sturdy.global.ui.screenBrightnessRoot
import com.kotlin.sturdy.global.ui.secureScreenRoot
import com.kotlin.sturdy.global.ui.showSystemUIRoot

/**
 * Enables or disables screen security to prevent screenshots and screen recording.
 *
 * @param enable true to enable security (default), false to disable
 */
fun Window.secureScreen(enable: Boolean = true) = secureScreenRoot(enable)

/**
 * Sets the screen brightness for this window.
 *
 * @param newBright Brightness value from 0 to 255
 */
fun Window.screenBrightness(newBright: Float) = screenBrightnessRoot(newBright)

/**
 * Keeps the screen on while this composable is in the composition.
 * Automatically removes the flag when disposed.
 *
 * Example:
 * ```
 * @Composable
 * fun VideoPlayerScreen() {
 *     KeepScreenOnAndRemoveAtDispose()
 *     // Video player content
 * }
 * ```
 */
@Composable
fun KeepScreenOnAndRemoveAtDispose() = KeepScreenOnAndRemoveAtDisposeRoot()

/** Prevents the screen from turning off while the activity is visible. */
fun Activity.keepScreenOn() = keepScreenOnRoot()

/** Allows the screen to turn off normally. */
fun Activity.removeKeepScreenOn() = removeKeepScreenOnRoot()

/**
 * Makes the activity draw behind the status bar (edge-to-edge) and sets the status bar icon color.
 *
 * @param black true for dark icons (use with light backgrounds), false for light icons (use with dark backgrounds)
 *
 * Example:
 * ```
 * // In your activity
 * window.baseActivityIgnoreStatusBarSpace(black = true) // Dark icons on light background
 * ```
 */
fun Window.baseActivityIgnoreStatusBarSpace(black: Boolean) = baseActivityIgnoreStatusBarSpaceRoot(black)

/**
 * Hides the status bar and navigation bar for an immersive full-screen experience.
 * System UI can be temporarily revealed by swiping from the edges.
 *
 * Example:
 * ```
 * // In your activity (e.g., for a video player or game)
 * window.hideAllSystemUI()
 * ```
 */
fun Window.hideAllSystemUI() = hideAllSystemUIRoot()

/**
 * Shows the status bar and navigation bar, exiting full-screen mode.
 * Content still draws edge-to-edge behind the system bars.
 */
fun Window.showSystemUI() = showSystemUIRoot()

/**
 * Configures the window for an alarm screen that appears over the lock screen.
 * Turns on the screen, keeps it on, dismisses the keyguard, and hides system UI.
 *
 * Requires permissions: SYSTEM_ALERT_WINDOW, WAKE_LOCK, and USE_FULL_SCREEN_INTENT (Android 10+)
 *
 * Example:
 * ```
 * // In your alarm activity's onCreate
 * window.lockAlarmFiredScreen()
 * ```
 */
fun Window.lockAlarmFiredScreen() = lockAlarmFiredScreenRoot()

/**
 * Configures the window for a music player that can show over the lock screen.
 * Displays in immersive mode with hidden system UI.
 *
 * Requires permission: SYSTEM_ALERT_WINDOW
 *
 * Example:
 * ```
 * // In your music player activity
 * window.lockMusicScreen()
 * ```
 */
fun Window.lockMusicScreen() = lockMusicScreenRoot()