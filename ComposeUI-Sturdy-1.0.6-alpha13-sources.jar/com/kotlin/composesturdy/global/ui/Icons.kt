@file:Suppress("unused")

package com.kotlin.composesturdy.global.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.kotlin.sturdy.global.ui.*

@Composable
fun rememberAdd(color: Color): ImageVector = rememberAddRoot(color)

@Composable
fun rememberBackArrow(color: Color): ImageVector = rememberBackArrowRoot(color)

@Composable
fun rememberExitToApp(color: Color): ImageVector = rememberExitToAppRoot(color)

@Composable
fun rememberDeleteText(color: Color): ImageVector = rememberDeleteTextRoot(color)

@Composable
fun rememberSearch(color: Color): ImageVector = rememberSearchRoot(color)

@Composable
fun rememberComment(color: Color): ImageVector = rememberCommentRoot(color)

@Composable
fun rememberChat(color: Color): ImageVector = rememberChatRoot(color)

@Composable
fun rememberTaxi(color: Color): ImageVector = rememberTaxiRoot(color)

@Composable
fun rememberProfile(color: Color): ImageVector = rememberProfileRoot(color)

@Composable
fun rememberDoneAll(color: Color): ImageVector = rememberDoneAllRoot(color)

@Composable
fun rememberFire(color: Color): ImageVector = rememberFireRoot(color)

@Composable
fun rememberSleepMoon(color: Color): ImageVector = rememberSleepMoonRoot(color)

@Composable
fun rememberHeart(color: Color): ImageVector = rememberHeartRoot(color)

@Composable
fun rememberSteps(color: Color): ImageVector = rememberStepsRoot(color)

@Composable
fun rememberMetabolic(color: Color): ImageVector = rememberMetabolicRoot(color)

@Composable
fun rememberDistance(color: Color): ImageVector = rememberDistanceRoot(color)

@Composable
fun rememberDumbbell(color: Color): ImageVector = rememberDumbbellRoot(color)

@Composable
fun rememberTimer(color: Color): ImageVector = rememberTimerRoot(color)

@Composable
fun rememberFile(color: Color): ImageVector = rememberFileRoot(color)

@Composable
fun rememberTriangleUp(color: Color): ImageVector = rememberTriangleUpRoot(color)

@Composable
fun rememberTriangleDown(color: Color): ImageVector = rememberTriangleDownRoot(color)

@Composable
fun rememberCloudUpload(color: Color): ImageVector = rememberCloudUploadRoot(color)

@Composable
fun rememberNext(color: Color): ImageVector = rememberNextRoot(color)

@Composable
fun rememberPrevious(color: Color): ImageVector = rememberPreviousRoot(color)

@Composable
fun rememberReplace(color: Color): ImageVector = rememberReplaceRoot(color)

@Composable
fun rememberEmptyStar(color: Color): ImageVector = rememberEmptyStarRoot(color)

@Composable
fun rememberStar(color: Color): ImageVector = rememberStarRoot(color)
