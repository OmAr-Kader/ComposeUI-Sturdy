@file:Suppress("unused", "RedundantOverride")

package com.kotlin.composesturdy.global.life

import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.retain.RetainObserver
import androidx.compose.runtime.retain.retain
import com.kotlin.sturdy.global.life.cancelScopeRoot
import com.kotlin.sturdy.global.life.collectAsRetainedStateRoot
import com.kotlin.sturdy.global.life.launchBackRoot
import com.kotlin.sturdy.global.life.launchMainRoot
import com.kotlin.sturdy.global.life.nullCheckerRoot
import com.kotlin.sturdy.global.life.withDefRoot
import com.kotlin.sturdy.global.life.withDefaultRoot
import com.kotlin.sturdy.global.life.withIODefaultRoot
import com.kotlin.sturdy.global.life.withIORoot
import com.kotlin.sturdy.global.life.withMainRoot
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlin.reflect.KProperty

// ─────────────────────────────────────────────────────────────────────────────
// Core: RetainedStateHolder
//
// Base class implementing RetainObserver — the ONLY valid observer interface
// for values passed to retain{}.
//
// !! IMPORTANT: Do NOT implement RememberObserver — it is ILLEGAL on retain{} values
//    and will throw at runtime. !!
//
// Lifecycle callbacks (all final — use the semantic hooks in subclasses):
//   onRetained()          ──► object first captured by retain{}     → onRetainedFirst()
//   onEnteredComposition()──► enters active composition              → onCompositionEntered()
//   onExitedComposition() ──► exits composition (may re-enter later) → onCompositionExited()
//   onRetired()           ──► permanently discarded, never returns   → onRetiredFinal() + scope cancel
//   onUnused()            ──► abandoned before onRetained completed  → onRetiredFinal() + scope cancel
//
// Key behavior difference vs RememberObserver:
//   retainedScope stays ALIVE across onExitedComposition/onEnteredComposition cycles
//   (config changes, back-stack, collapsed content). Cancel ONLY in onRetired/onUnused.
// ─────────────────────────────────────────────────────────────────────────────

abstract class RetainedStateHolder<P>(
    protected val project: P
) : RetainObserver, CoroutineScope {
    val retainedScope: CoroutineScope = CoroutineScope(
        SupervisorJob() + Dispatchers.Main.immediate
    )
    /**
     * Retain-scoped coroutine scope.
     * Survives configuration changes — canceled ONLY when [onRetired] or [onUnused] fires.
     * Replaces viewModelScope.
     */
    override val coroutineContext: kotlin.coroutines.CoroutineContext
        get() = SupervisorJob() + Dispatchers.Default + CoroutineExceptionHandler { _, _ -> }


    var isInCompositionRaw= false

    /** True while this holder is inside an active composition. */
    val isInComposition: Boolean get() = isInCompositionRaw

    // ── Semantic hooks — override these in subclasses ─────────────────────────

    /**
     * Called once when this holder is first captured by [retain].
     * Start coroutines, collect flows, initialize resources here.
     * Equivalent to ViewModel init {}.
     */
    open fun onRetainedFirst() {}
    open suspend fun onClear() {}

    /**
     * Called each time the holder enters active composition.
     * May fire more than once (after config change restoration, etc.).
     * Equivalent to onStart().
     */
    open fun onCompositionEntered() {}

    /**
     * Called each time the holder exits composition (but is NOT yet retired).
     * The holder and its [retainedScope] are still alive — do NOT cancel work here.
     * Equivalent to onStop().
     */
    open fun onCompositionExited() {}

    /**
     * Called once when this holder is permanently discarded and will never re-enter composition.
     * [retainedScope] is already canceled before this is called.
     * Equivalent to ViewModel.onCleared(). Release non-coroutine resources here.
     */
    open fun onRetiredFinal() {}

    // ── RetainObserver — all final to enforce correct lifecycle semantics ──────

    final override fun onRetained() {
        onRetainedFirst()
    }

    final override fun onEnteredComposition() {
        isInCompositionRaw = true
        onCompositionEntered()
    }

    final override fun onExitedComposition() {
        isInCompositionRaw = false
        onCompositionExited()
    }

    final override fun onRetired() {
        retainedScope.cancelScopeRoot()
        cancelScopeRoot()
        onRetiredFinal()
    }

    /**
     * Mirrors [androidx.compose.runtime.RememberObserver.onAbandoned].
     * Fired if composition was abandoned before this object's [onRetained] was paired with cleanup.
     * Release any constructor-allocated resources here.
     */
    final override fun onUnused() {
        retainedScope.cancelScopeRoot()
        cancelScopeRoot()
        onRetiredFinal()
    }


    /**
     * Launches a coroutine on the Default dispatcher with exception handling and timeout.
     *
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     * @return Job instance for the launched coroutine
     */
    fun launchBack(
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> Unit
    ): Job = launchBackRoot(failed, block)

    /**
     * Launches a coroutine on the Main dispatcher with exception handling and timeout.
     *
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     * @return Job instance for the launched coroutine
     */
    fun launchMain(
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> Unit
    ): Job = retainedScope.launchMainRoot(failed, block)

    /**
     * Executes a suspend block on the Main dispatcher with exception handling and timeout.
     * Suspends until the block completes.
     *
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     */
    suspend fun withMain(
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> Unit,
    ) = withMainRoot(failed, block)

    /**
     * Executes a suspend block on the Default dispatcher with exception handling and timeout.
     * Suspends until the block completes.
     *
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     */
    suspend fun withDef(
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> Unit,
    ) = withDefRoot(failed, block)

    /**
     * Executes a suspend block on the IO dispatcher with exception handling and timeout.
     * Suspends until the block completes.
     *
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     */
    suspend fun withIO(
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> Unit,
    ) = withIORoot(failed, block)

    /**
     * Executes a suspend block on the Main dispatcher and returns a result.
     * Returns the default value on exception or timeout.
     *
     * @param D The return type
     * @param def Default value to return on exception or timeout
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     * @return The result of the block or the default value on error
     */
    suspend fun <D> withMain(
        def: D,
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> D,
    ): D = withMainRoot(def, failed, block)

    /**
     * Executes a suspend block on the Default dispatcher and returns a result.
     * Returns the default value on exception or timeout.
     *
     * @param D The return type
     * @param def Default value to return on exception or timeout
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     * @return The result of the block or the default value on error
     */
    suspend fun <D> withDefault(
        def: D,
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> D,
    ): D = withDefaultRoot(def, failed, block)

    /**
     * Executes a suspend block on the IO dispatcher and returns a result.
     * Returns the default value on exception or timeout.
     *
     * @param D The return type
     * @param def Default value to return on exception or timeout
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     * @return The result of the block or the default value on error
     */
    suspend fun <D> withIODefault(
        def: D,
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> D,
    ): D = withIODefaultRoot(def, failed, block)

    /**
     * Checks if the Context is null and cancels the current scope if it is.
     * Useful for preventing operations when Context becomes invalid.
     */
    suspend fun android.content.Context?.nullChecker() = nullCheckerRoot()

    fun CoroutineScope.cancelScope() = cancelScopeRoot()

}

// ─────────────────────────────────────────────────────────────────────────────
// Composable: rememberRetained
//
// Wraps retain{} — NOT remember{} — so the holder survives:
//   • Configuration changes (rotation, locale, font-size)
//   • Back-stack removal with potential restoration
//   • Activity recreation
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Creates and retains a [RetainedStateHolder] for the current composition using [retain].
 *
 * ```kotlin
 * val holder = rememberRetained { ProfileHolder(repository) }
 * ```
 *
 * @param keys    Changing any key retires the existing holder and creates a new one.
 * @param factory Lambda producing the [T] instance.
 */
@Composable
inline fun <reified P, reified T: RetainedStateHolder<P>> rememberRetained(
    vararg keys: Any?,
    crossinline factory: () -> T
): T = retain(*keys) { factory() }

// ─────────────────────────────────────────────────────────────────────────────
// State delegate: retainedStateOf
//
// Property delegate wrapping MutableState<T> for use inside RetainedStateHolder.
// Compose reads are tracked automatically — no collectAsState() needed.
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Property delegate wrapping [mutableStateOf] for use inside [RetainedStateHolder].
 * Triggers recomposition on write.
 *
 * ```kotlin
 * class ProfileHolder : RetainedStateHolder() {
 *     var uiState by retainedStateOf<UiState<User>>(UiState.Idle)
 *         private set
 * }
 * ```
 */
fun <T, P> retainedStateOf(initialValue: T): RetainedStateDelegate<T, P> = RetainedStateDelegate(mutableStateOf(initialValue))

class RetainedStateDelegate<T, P>(private val state: MutableState<T>) {
    operator fun getValue(thisRef: RetainedStateHolder<P>, property: KProperty<*>): T =
        state.value

    operator fun setValue(thisRef: RetainedStateHolder<P>, property: KProperty<*>, value: T) {
        state.value = value
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Flow helpers
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Collects this [Flow] in the holder's retained scope.
 * Call from [RetainedStateHolder.onRetainedFirst] — survives config changes.
 *
 * ```kotlin
 * override fun onRetainedFirst() {
 *     repository.stream.collectInRetainedScope(this) { value = it }
 * }
 * ```
 */
fun <T, P> Flow<T>.collectInRetainedScope(
    holder: RetainedStateHolder<P>,
    onEach: (T) -> Unit
): Job = holder.launchMainRoot {
    collect { onEach(it) }
}

/**
 * Collects a [StateFlow] as Compose [State], scoped to the holder's retained scope.
 *
 * ```kotlin
 * val items by externalFlow.collectAsRetainedState(holder.retainedScope)
 * ```
 */
@Composable
fun <T> StateFlow<T>.collectAsRetainedState(scope: CoroutineScope): State<T> = collectAsRetainedStateRoot(scope)

// ─────────────────────────────────────────────────────────────────────────────
// UiState — sealed async result wrapper
// ─────────────────────────────────────────────────────────────────────────────

sealed class UiState<out T> {
    data object Idle    : UiState<Nothing>()
    data object Loading : UiState<Nothing>()
    data class  Success<T>(val data: T)                                  : UiState<T>()
    data class  Error(val message: String, val cause: Throwable? = null) : UiState<Nothing>()

    val isLoading:   Boolean  get() = this is Loading
    val isSuccess:   Boolean  get() = this is Success
    val isError:     Boolean  get() = this is Error
    val dataOrNull:  T?       get() = (this as? Success)?.data
    val errorOrNull: String?  get() = (this as? Error)?.message
}

/**
 * Wraps a suspending [block] as [UiState], auto-mapping exceptions to [UiState.Error].
 * Always re-throws [CancellationException] — never swallows scope cancellation.
 *
 * ```kotlin
 * fun load(id: String) = launch {
 *     uiState = UiState.Loading
 *     uiState = runAsUiState { repository.get(id) }
 * }
 * ```
 */
suspend fun <T> runAsUiState(block: suspend () -> T): UiState<T> = try {
    UiState.Success(block())
} catch (e: CancellationException) {
    throw e
} catch (e: Exception) {
    UiState.Error(e.message ?: "Unknown error", e)
}
