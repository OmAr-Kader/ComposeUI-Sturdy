@file:Suppress("unused")

package com.kotlin.composesturdy.global.life

import com.kotlin.sturdy.global.life.catchyRoot
import com.kotlin.sturdy.global.life.catchyUnitRoot
import com.kotlin.sturdy.global.life.toCatchSusRunTimeOutRoot
import com.kotlin.sturdy.global.life.toCatchSusTimeOutRoot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.cancellation.CancellationException

/**
 * Extension property that wraps a suspend function with timeout and exception handling.
 * Executes the job with a 4.5-second timeout and returns the receiver value on failure or timeout.
 *
 * @param D The type of the receiver and return value
 * @param 'failed' Callback invoked with error message when an exception occurs
 * @param 'job' The suspend function to execute within the timeout
 * @return A suspend function that returns the result or the original receiver on error/timeout
 */
inline val <D> D.toCatchSusRunTimeOut: (failed: (String) -> Unit, suspend CoroutineScope.() -> D) -> (suspend CoroutineScope.() -> D)
    get() = toCatchSusRunTimeOutRoot

/**
 * Property that wraps a suspend Unit function with timeout and exception handling.
 * Executes the job with a 4.5-second timeout and catches all exceptions.
 *
 * @param 'failed' Callback invoked with error message when an exception occurs
 * @param 'job' The suspend function to execute within the timeout
 * @return A suspend function that executes the job safely
 */
inline val toCatchSusTimeOut: (failed: (String) -> Unit, job: suspend CoroutineScope.() -> Unit) -> (suspend CoroutineScope.() -> Unit)
    get() = toCatchSusTimeOutRoot

/**
 * Executes a block of code with comprehensive exception handling.
 * Returns the result of the block or a default value if an exception occurs.
 *
 * @param R The return type
 * @param def Default value to return on exception
 * @param failed Optional callback invoked with error message when an exception occurs
 * @param block The code block to execute
 * @return The result of the block or the default value on exception
 */
inline fun <R> catchy(def: R, failed: (String) -> Unit = {}, block: () -> R): R = catchyRoot(def, failed, block)

/**
 * Executes a Unit-returning block of code with comprehensive exception handling.
 * Catches and reports all exceptions without rethrowing.
 *
 * @param failed Optional callback invoked with error message when an exception occurs
 * @param block The code block to execute
 */
inline fun catchyUnit(failed: (String) -> Unit = {}, block: () -> Unit) = catchyUnitRoot(failed, block)
