@file:Suppress("SameParameterValue")

package com.kotlin.composesturdy.global.util

import com.kotlin.composesturdy.global.util.LogKit.setIsDebug
import com.kotlin.sturdy.global.util.LogKitRoot

/**
 * A lightweight logging utility for Android that conditionally prints logs
 * based on the debug state of the application.
 *
 * Use [setIsDebug] to enable or disable logging (typically from `BuildConfig.DEBUG`).
 *
 * Example:
 * ```
 * LogKit.setIsDebug(BuildConfig.DEBUG)
 * LogKit.d("MainActivity", "Debug message")
 * ```
 */
@Suppress("unused")
object LogKit {

    /** Flag indicating whether logging is enabled. */
    @Volatile
    @JvmStatic
    var debug: Boolean? = LogKitRoot.debug

    private val isDebug: Boolean get() = debug == true

    /**
     * Enables or disables debug logging.
     * @param debug true to enable logging, false to disable.
     */
    fun setIsDebug(debug: Boolean) = LogKitRoot.setIsDebug(debug)

    /**
     * Logs a warning message if debug mode is enabled.
     * @param tag Tag identifying the log source.
     * @param message Message to log.
     */
    fun w(tag: String, message: String, withCodeInfos: Boolean = true) = LogKitRoot.w(tag, message, withCodeInfos)

    /**
     * Logs a warning message if debug mode is enabled.
     * @param message Message to log.
     */
    fun w(message: String, withCodeInfos: Boolean = true) = LogKitRoot.w(message, withCodeInfos)

    /**
     * Logs an error message if debug mode is enabled.
     * @param tag Tag identifying the log source.
     * @param message Message to log.
     */
    fun e(tag: String, message: String, withCodeInfos: Boolean = true) = LogKitRoot.e(tag, message, withCodeInfos)

    /**
     * Logs an error message if debug mode is enabled.
     * @param message Message to log.
     */
    fun e(message: String, withCodeInfos: Boolean = true) = LogKitRoot.e(message, withCodeInfos)

    /**
     * Logs an error message and throwable if debug mode is enabled.
     * @param tag Tag identifying the log source.
     * @param message Message to log.
     * @param tro Throwable to include in the log.
     */
    fun e(tag: String, message: String, tro: Throwable?, withCodeInfos: Boolean = true) = LogKitRoot.e(tag, message, tro, withCodeInfos)

    /**
     * Logs an error message and throwable if debug mode is enabled.
     * @param tro Throwable to include in the log.
     */
    fun e(tro: Throwable?, withCodeInfos: Boolean = true) = LogKitRoot.e(tro, withCodeInfos)

    /**
     * Logs an error message and throwable if debug mode is enabled.
     * @param message Message to log.
     * @param tro Throwable to include in the log.
     */
    fun e(message: String, tro: Throwable?, withCodeInfos: Boolean = true) = LogKitRoot.e(message, tro, withCodeInfos)

    /**
     * Logs an info message if debug mode is enabled.
     * @param tag Tag identifying the log source.
     * @param message Message to log.
     */
    fun i(tag: String, message: String, withCodeInfos: Boolean = true) = LogKitRoot.i(tag, message, withCodeInfos)

    /**
     * Logs an info message if debug mode is enabled.
     * @param message Message to log.
     */
    fun i(message: String, withCodeInfos: Boolean = true) = LogKitRoot.i(message, withCodeInfos)

    /**
     * Logs a debug message if debug mode is enabled.
     * @param tag Tag identifying the log source.
     * @param message Message to log.
     */
    fun d(tag: String, message: String, withCodeInfos: Boolean = true) = LogKitRoot.d(tag, message, withCodeInfos)

    /**
     * Logs a debug message if debug mode is enabled.
     * @param message Message to log.
     */
    fun d(message: String, withCodeInfos: Boolean = true) = LogKitRoot.d(message, withCodeInfos)

    /**
     * Prints a formatted log line to the console if debug mode is enabled.
     * @param msg Message to print.
     */
    fun printLine(msg: String, withCodeInfos: Boolean = true) = LogKitRoot.printLine(msg, withCodeInfos)

    /**
     * Pretty-prints JSON with a lightweight dedicated JSON configuration.
     *
     * Performance note: this is the recommended option for normal debug usage.
     */
    fun json(message: String, withCodeInfos: Boolean = true) = LogKitRoot.json(message, withCodeInfos)
}