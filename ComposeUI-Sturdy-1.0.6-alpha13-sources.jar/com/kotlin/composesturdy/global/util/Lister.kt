@file:Suppress("unused")

package com.kotlin.composesturdy.global.util

import com.kotlin.sturdy.global.util.averageSafeDoubleRoot
import com.kotlin.sturdy.global.util.averageSafeLongRoot
import com.kotlin.sturdy.global.util.ifNotEmptyRoot
import com.kotlin.sturdy.global.util.ifTrueRoot
import com.kotlin.sturdy.global.util.replaceRoot

/**
 * Executes [defaultValue] if the list is not empty and returns its result; otherwise returns `null`.
 *
 * @param defaultValue Lambda executed on the non-empty list.
 * @return The result of [defaultValue], or `null` if the list is empty.
 *
 * ### Example
 * ```kotlin
 * val names = listOf("Mark", "Down")
 * val result = names.ifNotEmpty { first() } // "Mark"
 * ```
 */
inline fun <C, R> List<C>.ifNotEmpty(defaultValue: List<C>.() -> R): R? = ifNotEmptyRoot(defaultValue)

/**
 * Executes [defaultValue] if the string is not empty and returns its result; otherwise returns `null`.
 *
 * @param defaultValue Lambda executed on the non-empty string.
 * @return The result of [defaultValue], or `null` if the string is empty.
 *
 * ### Example
 * ```kotlin
 * val name = "Omar"
 * val result = name.ifNotEmpty { uppercase() } // "OMAR"
 * ```
 */
inline fun <R> String.ifNotEmpty(defaultValue: String.() -> R): R? = ifNotEmptyRoot(defaultValue)

/**
 * Replaces the first element matching [predicate] with the result of [invoke].
 *
 * @param predicate Condition to find the element to replace.
 * @param invoke Transformation applied to the matching element.
 * @return A new [List] reflecting the replacement; if no match is found, the original list is returned.
 *
 * ### Example
 * ```kotlin
 * val list = mutableListOf(1, 2, 3)
 * val updated = list.replace({ it == 2 }) { it * 10 } // [1, 20, 3]
 * ```
 */
fun <T> MutableList<T>.replace(predicate: (T) -> Boolean, invoke: (T) -> T): List<T> = replaceRoot(predicate, invoke)

/**
 * Replaces the first element matching [predicate] with the result of [invoke], then triggers [newInvoke].
 *
 * @param predicate Condition to find the element to replace.
 * @param invoke Transformation applied to the matching element.
 * @param newInvoke Callback executed after replacement, receiving the updated list and the replaced element (or `null` if not found).
 *
 * ### Example
 * ```kotlin
 * val list = mutableListOf(1, 2, 3)
 * list.replace({ it == 2 }, { it * 10 }) { updated, item ->
 *     println("Updated: $updated, Replaced: $item")
 * }
 * // Output: Updated: [1, 20, 3], Replaced: 20
 * ```
 */
fun <T> MutableList<T>.replace(predicate: (T) -> Boolean, invoke: (T) -> T, newInvoke: (List<T>, T?) -> Unit) = replaceRoot(predicate, invoke, newInvoke)

/**
 * Returns the average of all elements or `0.0` if the sum is zero.
 *
 * Prevents division by zero by checking if the sum of the elements equals `0.0`.
 *
 * @return The average value, or `0.0` if all elements are zero or the collection is empty.
 *
 * ### Example
 * ```kotlin
 * val numbers = listOf(0.0, 0.0)
 * val avg = numbers.averageSafeDouble() // 0.0
 * ```
 */
fun Iterable<Double>.averageSafeDouble(): Double = averageSafeDoubleRoot()

/**
 * Returns the average of all [Long] elements or `0.0` if their sum equals zero.
 *
 * Useful for safely calculating averages while avoiding unnecessary computation
 * when all elements are zero or the collection is empty.
 *
 * @return The average as a [Double], or `0.0` if all elements are zero or none exist.
 *
 * ### Example
 * ```kotlin
 * val numbers = listOf(10L, 20L, 30L)
 * val avg = numbers.averageSafeLong() // 20.0
 * ```
 */
fun Iterable<Long>.averageSafeLong(): Double = averageSafeLongRoot()

/**
 * Executes [invoke] only if the boolean value is `true`.
 *
 * This is a concise utility for conditionally executing code without an explicit `if` statement.
 *
 * @param invoke The block of code to execute when the condition is `true`.
 *
 * ### Example
 * ```kotlin
 * val isLoggedIn = true
 * isLoggedIn.ifTrue {
 *     println("Welcome back!")
 * }
 * ```
 */
inline fun Boolean.ifTrue(invoke: () -> Unit) = ifTrueRoot(invoke)