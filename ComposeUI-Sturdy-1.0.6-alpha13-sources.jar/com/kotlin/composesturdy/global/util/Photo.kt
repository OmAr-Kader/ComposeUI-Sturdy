@file:Suppress("unused")

package com.kotlin.composesturdy.global.util

import com.kotlin.sturdy.global.util.compressImageToMax1MBRoot
import java.io.File

/**
 * Compresses an image file to stay under a maximum byte size.
 *
 * The function first downscales very large images, then reduces JPEG quality
 * in steps until the output size is below [maxSizeInBytes] or [minQuality] is reached.
 *
 * @param maxSizeInBytes Target maximum output size in bytes.
 * @param minQuality Lowest JPEG quality allowed during compression.
 * @return Compressed image bytes, original file bytes on fallback, or empty bytes if unreadable.
 */
suspend fun File.compressImageToMax1MB(
    maxSizeInBytes: Int = 1_000_000,
    minQuality: Int = 40
): ByteArray = compressImageToMax1MBRoot(maxSizeInBytes, minQuality)
