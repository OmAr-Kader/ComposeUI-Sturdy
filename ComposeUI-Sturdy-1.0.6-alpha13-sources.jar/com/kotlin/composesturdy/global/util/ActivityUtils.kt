@file:Suppress("unused")

package com.kotlin.composesturdy.global.util

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Parcel
import android.os.Parcelable
import com.kotlin.sturdy.global.util.dialNumberRoot
import com.kotlin.sturdy.global.util.fetchParcelableExtraRoot
import com.kotlin.sturdy.global.util.openWebsiteRoot
import com.kotlin.sturdy.global.util.parcelableRoot
import com.kotlin.sturdy.global.util.shareTextRoot

/**
 * Reads a [Parcelable] from a [Parcel] using the API-compatible overload.
 *
 * @param cls Parcelable class type used for typed deserialization.
 * @return Parsed parcelable value or null.
 */
inline fun <reified T: Parcelable> Parcel.parcelable(cls: Class<T>): T? = parcelableRoot(cls)

/**
 * Reads a [Parcelable] from a [Bundle] using the API-compatible overload.
 *
 * @param key Bundle key used to read the value on newer Android versions.
 * @return Parsed parcelable value or null.
 */
inline fun <reified T: Parcelable> Bundle.parcelable(key: String): T? = parcelableRoot(key)

/**
 * Reads a [Parcelable] extra from an [Intent] with API-level compatibility.
 *
 * @param key Extra key.
 * @param clazz Parcelable class used on newer Android versions.
 * @return Parsed parcelable value or null.
 */
inline fun <reified T: Parcelable> Intent.fetchParcelableExtra(key: String, clazz: Class<T>): T? = fetchParcelableExtraRoot(key, clazz)

/**
 * Opens the dialer with [number] prefilled.
 *
 * @param number Phone number to place in the dial intent.
 */
suspend fun Context.dialNumber(number: String) = dialNumberRoot(number)


/**
 * Opens this URL string in a browser app.
 *
 * @param context Context used to start the browser activity.
 */
suspend fun String.openWebsite(context: Context) = openWebsiteRoot(context)

/**
 * Shares this string as plain text via Android's share sheet.
 *
 * @param context Context used to launch the chooser target.
 */
suspend fun String.shareText(context: Context) = shareTextRoot(context)