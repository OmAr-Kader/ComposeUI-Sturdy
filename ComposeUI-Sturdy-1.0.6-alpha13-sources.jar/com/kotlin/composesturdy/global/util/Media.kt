@file:Suppress("unused")

package com.kotlin.composesturdy.global.util

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.media.MediaPlayer
import android.net.Uri
import androidx.compose.runtime.Composable
import coil3.ImageLoader
import coil3.request.ImageRequest
import coil3.size.Size
import com.kotlin.sturdy.global.util.countryCodeRoot
import com.kotlin.sturdy.global.util.fetchCountryCodeRoot
import com.kotlin.sturdy.global.util.filePickerOnlyImageRoot
import com.kotlin.sturdy.global.util.filePickerRoot
import com.kotlin.sturdy.global.util.getByteArrayFromUriRoot
import com.kotlin.sturdy.global.util.getMimeTypeExtensionRoot
import com.kotlin.sturdy.global.util.getMimeTypeRoot
import com.kotlin.sturdy.global.util.getVideoDurationRoot
import com.kotlin.sturdy.global.util.imageBuildrRoot
import com.kotlin.sturdy.global.util.isDarkModeRoot
import com.kotlin.sturdy.global.util.isImageRoot
import com.kotlin.sturdy.global.util.isTabletRoot
import com.kotlin.sturdy.global.util.isVideoRoot
import com.kotlin.sturdy.global.util.rememberImageRequestResizeRoot
import com.kotlin.sturdy.global.util.rememberImageRequestRoot
import com.kotlin.sturdy.global.util.shareLinkRoot
import com.kotlin.sturdy.global.util.videoImageBuildrRoot
import kotlinx.coroutines.Dispatchers

/**
 * Creates an ImageRequest builder function for loading images with Coil.
 * Configures caching policies and enables crossfade animation.
 * Memory cache is disabled while disk and network caches are enabled.
 *
 * @return A function that takes an image URL/path and returns a configured ImageRequest
 */
val Context.imageBuildr: (String) -> ImageRequest
    get() = imageBuildrRoot

/**
 * Remembers a Coil [coil3.request.ImageRequest] for the provided URL.
 *
 * @param url Image URL or local path.
 * @param crossFade Enables Coil crossfade animation when true.
 * @return Memoized request configured with disk/network cache.
 */
@Composable
fun rememberImageRequest(
    url: String,
    crossFade: Boolean = false
): ImageRequest = rememberImageRequestRoot(url, crossFade)

/**
 * Remembers a Coil request for [url] and optionally applies a target [size].
 *
 * @param url Image URL or local path.
 * @param size Optional requested image size for decoding.
 * @param crossFade Enables Coil crossfade animation when true.
 * @return Memoized request bound to this [Context].
 */
@Composable
fun Context.rememberImageRequestResize(
    url: String,
    size: Size?,
    crossFade: Boolean = false
): ImageRequest = rememberImageRequestResizeRoot(url, size, crossFade)

/**
 * Creates an ImageLoader configured for loading video frame thumbnails.
 * Includes VideoFrameDecoder for extracting frames from video files.
 * Memory cache is disabled while disk and network caches are enabled.
 *
 * ### Example
 * ```kotlin
 * val painter = rememberAsyncImagePainter(
 *     model = videoUrl,
 *     imageLoader = LocalContext.current.videoImageBuildr,
 * )
 * ```
 * @return Configured ImageLoader for video thumbnail loading
 */
val Context.videoImageBuildr: ImageLoader
    get() = videoImageBuildrRoot

/**
 * Determines whether the system is currently using dark mode (night mode).
 *
 * Uses the [Configuration.UI_MODE_NIGHT_MASK] flag to detect the active theme mode.
 *
 * @return `true` if dark mode is enabled or undetermined, otherwise `false`.
 */
val Context.isDarkMode: Boolean
    get() = isDarkModeRoot


/**
 * Determines whether the device is classified as a tablet based on screen size.
 *
 * Uses the [Configuration.SCREENLAYOUT_SIZE_MASK] to check if the screen size
 * is large or larger (i.e., `SCREENLAYOUT_SIZE_LARGE` or `SCREENLAYOUT_SIZE_XLARGE`).
 *
 * @return `true` if the device is a tablet, otherwise `false`.
 */
val Context.isTablet: Boolean
    get() = isTabletRoot

/**
 * Retrieves the file extension (including a leading dot) from a given [Uri].
 *
 * - If the URI uses the `content://` scheme, the MIME type is resolved using the [ContentResolver].
 * - If it uses the `file://` scheme, the extension is extracted from the file path.
 *
 * @param uri The [Uri] to extract the file extension from.
 * @return The file extension (e.g., `.jpg`, `.mp4`), or an empty string if unknown.
 */
fun Context.getMimeTypeExtension(uri: Uri): String = getMimeTypeExtensionRoot(uri)

/**
 * Retrieves the MIME type corresponding to a given file extension.
 *
 * @param extension The file extension (e.g., `.jpg` or `jpg`).
 * @return The MIME type string (e.g., `image/jpeg`), or `null` if unknown.
 */
fun getMimeType(extension: String): String? = getMimeTypeRoot(extension)

/**
 * Determines whether the given file extension corresponds to an image MIME type.
 *
 * @param extension The file extension (e.g., `.png` or `jpg`).
 * @return `true` if the MIME type starts with `image`, otherwise `false`.
 */
fun isImage(extension: String): Boolean = isImageRoot(extension)

/**
 * Determines whether the given file extension corresponds to a video MIME type.
 *
 * @param extension The file extension (e.g., `.mp4` or `mov`).
 * @return `true` if the MIME type starts with `video`, otherwise `false`.
 */
fun isVideo(extension: String): Boolean = isVideoRoot(extension)

/**
 * Opens a system file picker to allow the user to select an image or video file.
 *
 * This composable extension on [Context] handles runtime permission requests automatically
 * (for different Android API levels) and launches the photo/video picker.
 * Once a file is selected, the [invoke] callback is triggered with:
 * - The selected file's [Uri].
 * - A Boolean indicating whether it’s an image (`true`), a video (`false`), or `null` if unknown.
 * - The file extension as a [String].
 *
 * @param invoke Callback invoked when the user selects a file, providing the [Uri], file type, and extension.
 * @return A lambda function that can be called to trigger the file picker manually.
 *
 * ### Example
 * ```kotlin
 * val openFilePicker = context.filePicker { uri, isImage, ext ->
 *     when (isImage) {
 *         true -> println("Selected image with extension: $ext")
 *         false -> println("Selected video with extension: $ext")
 *         null -> println("Unknown file type")
 *     }
 * }
 *
 * // Trigger the picker (e.g., on button click)
 * Button(onClick = openFilePicker) {
 *     Text("Pick a file")
 * }
 * ```
 */
@Composable
fun Context.filePicker(
    invoke: (Uri, isImage: Boolean?, extension: String) -> Unit,
): () -> Unit = filePickerRoot(invoke)


/**
 * Opens a system picker to allow the user to select **only image files**.
 *
 * This composable extension on [Context] manages permission requests based on the Android version
 * and launches the system’s image picker once permissions are granted.
 * When a file is selected, the [invoke] callback is executed with:
 * - The selected file’s [Uri].
 * - The file’s extension as a [String].
 *
 * @param invoke Callback invoked when the user selects an image file, providing the [Uri] and extension.
 * @return A lambda function that can be called to trigger the image picker manually.
 *
 * ### Example
 * ```kotlin
 * val openImagePicker = context.filePickerOnlyImage { uri, ext ->
 *     println("Selected image URI: $uri, Extension: $ext")
 * }
 *
 * Button(onClick = openImagePicker) {
 *     Text("Pick an image")
 * }
 * ```
 */
@Composable
fun Context.filePickerOnlyImage(
    invoke: (Uri, extension: String) -> Unit,
): () -> Unit = filePickerOnlyImageRoot(invoke)

/**
 * Shares a text-based link using the system's share sheet.
 *
 * Creates an implicit [Intent] with the given [url] and launches a chooser dialog
 * allowing the user to share the link through available apps (e.g., messaging, email, browsers).
 *
 * @param url The web link or text to be shared.
 *
 */
suspend fun Context.shareLink(url: String) = shareLinkRoot(url)

/**
 * Reads the content of a [Uri] and returns it as a [ByteArray].
 *
 * This function runs on a background thread (via [Dispatchers.Default]) and is suitable for
 * reading image, video, or document files. Returns `null` if the URI cannot be opened.
 *
 * @param uri The [Uri] to read from.
 * @return The file content as a [ByteArray], or `null` if reading fails.
 *
 */
suspend fun Context.getByteArrayFromUri(uri: Uri): ByteArray? = getByteArrayFromUriRoot(uri)

/**
 * Retrieves the duration of a video in milliseconds.
 *
 * Uses [MediaPlayer] to load the video at the given [videoPath] URI
 * and returns its total duration. Returns `0` if the duration cannot be determined
 * or an error occurs during processing.
 *
 * @param videoPath The [Uri] of the video file.
 * @return The duration of the video in milliseconds, or `0` if unavailable.
 *
 */
suspend fun Context.getVideoDuration(videoPath: Uri): Long = getVideoDurationRoot(videoPath)

/**
 * Resolves a lowercase ISO country code from SIM, network, or device locale.
 *
 * Order of resolution: SIM country, current network country, then default locale.
 * Returns null when none can be resolved.
 */
inline val Context.countryCode: String?
    get() = countryCodeRoot

/**
 * Suspended variant of country resolution using SIM, network, then locale.
 *
 * @param default Caller-provided fallback value (currently not used by implementation).
 * @return Lowercase ISO country code, or null when unavailable.
 */
suspend fun Context.fetchCountryCode(default: String): String? = fetchCountryCodeRoot(default)
