@file:Suppress("unused")

package com.kotlin.composesturdy.global.util

import com.kotlin.sturdy.global.util.dateBeforeHourInstantRoot
import com.kotlin.sturdy.global.util.dateBeforeHourRoot
import com.kotlin.sturdy.global.util.dateInstantRoot
import com.kotlin.sturdy.global.util.dateNowMillsRoot
import com.kotlin.sturdy.global.util.dateNowOnlyHourRoot
import com.kotlin.sturdy.global.util.dateNowRoot
import com.kotlin.sturdy.global.util.dateNowUTCMILLSOnlyHourRoot
import com.kotlin.sturdy.global.util.dateNowUTCMILLSRoot
import com.kotlin.sturdy.global.util.dateNowUTCRoot
import com.kotlin.sturdy.global.util.dateStrRoot
import com.kotlin.sturdy.global.util.dateTimeRoot
import com.kotlin.sturdy.global.util.formatMillisecondsToHoursRoot
import com.kotlin.sturdy.global.util.fullFormatMillisecondsToHoursRoot
import com.kotlin.sturdy.global.util.observeNextHourRoot
import com.kotlin.sturdy.global.util.observeSpecificTimeRoot
import com.kotlin.sturdy.global.util.timestampRoot
import com.kotlin.sturdy.global.util.toInstantRoot
import com.kotlin.sturdy.global.util.toTimestampHourMinAMPMRoot
import com.kotlin.sturdy.global.util.toTimestampRoot
import com.kotlin.sturdy.global.util.toTimestampWithDaysRoot
import com.kotlin.sturdy.global.util.toTimestampYearRoot
import kotlinx.datetime.LocalDateTime
import kotlin.time.Instant

/**
 * Returns the current system date and time as an ISO-8601 string.
 *
 * Example output: `"2025-10-18T12:45:30.123Z"`
 */
inline val dateNow: String
    get() = dateNowRoot

/**
 * Returns the current date and time in UTC as an ISO-8601 string.
 *
 * Example output: `"2025-10-18T12:45:30"`
 */
inline val dateNowUTC: String
    get() = dateNowUTCRoot

/**
 * Returns the [kotlin.time.Instant] representing the time exactly one hour before the current moment.
 */
inline val dateBeforeHourInstant: Instant
    get() = dateBeforeHourInstantRoot

/**
 * Returns the ISO-8601 string representation of the time one hour ago.
 *
 * Example output: `"2025-10-18T11:45:30.123Z"`
 */
inline val dateBeforeHour: String
    get() = dateBeforeHourRoot

/**
 * Returns the current system time in milliseconds since the Unix epoch.
 */
inline val dateNowMills: Long
    get() = dateNowMillsRoot

/**
 * Returns the current UTC time in milliseconds since the Unix epoch.
 */
inline val dateNowUTCMILLS: Long
    get() = dateNowUTCMILLSRoot

/**
 * Returns the current UTC date and hour as a formatted string.
 *
 * The format used is `"yyyy/MM/dd HH"`.
 *
 * Example output: `"2025/10/18 12"`
 */
inline val dateNowUTCMILLSOnlyHour: String
    get() = dateNowUTCMILLSOnlyHourRoot

/**
 * Converts a date-time [String] into a formatted hour and minute representation with AM/PM.
 *
 * The string is parsed via `dateInstant.dateTime` (must be a valid date-time format),
 * then formatted as `"hh:mm AM/PM"`.
 *
 * Example output: `"3:05 PM"`
 *
 * ### Example
 * ```kotlin
 * val formatted = "2025-10-18T15:05:00Z".toTimestampHourMinAMPM
 * println(formatted) // "3:05 PM"
 * ```
 */
val String.toTimestampHourMinAMPM: String get() = toTimestampHourMinAMPMRoot

/**
 * Returns the current system hour in 12-hour format with AM/PM.
 *
 * Example output: `"3 PM"`
 *
 * ### Example
 * ```kotlin
 * val hour = dateNowOnlyHour
 * println(hour) // "10 AM"
 * ```
 */
inline val dateNowOnlyHour: String
    get() = dateNowOnlyHourRoot

/**
 * Converts this [Long] value, representing milliseconds since the Unix epoch, into a [kotlin.time.Instant].
 *
 * ### Example
 * ```kotlin
 * val instant = System.currentTimeMillis().toInstant
 * println(instant) // 2025-10-18T12:45:00.123Z
 * ```
 */
val Long.toInstant: Instant get() = toInstantRoot

/**
 * Parses this ISO-8601 date-time [String] into a [kotlin.time.Instant].
 *
 * The string must be in a valid format (e.g., `"2025-10-18T12:45:00Z"`).
 *
 * ### Example
 * ```kotlin
 * val instant = "2025-10-18T12:45:00Z".dateInstant
 * println(instant.epochMilliseconds)
 * ```
 */
val String.dateInstant: Instant get() = dateInstantRoot

/**
 * Converts this [kotlin.time.Instant] into a formatted local date-time [String]
 * based on the current system time zone.
 *
 * Example output: `"2025-10-18T15:30:45"`
 */
val Instant.dateStr: String
    get() = dateStrRoot

/**
 * Converts this [kotlin.time.Instant] into a [kotlinx.datetime.LocalDateTime]
 * using the system’s default time zone.
 *
 * ### Example
 * ```kotlin
 * val dateTime = Clock.System.now().dateTime
 * println(dateTime.hour) // e.g., 15
 * ```
 */
val Instant.dateTime: LocalDateTime get() = dateTimeRoot

/**
 * Formats this [kotlinx.datetime.LocalDateTime] as `"MM/dd HH:mm"`.
 *
 * Example output: `"10/18 15:45"`
 */
val LocalDateTime.timestamp: String get() = timestampRoot

/**
 * Converts this [Long] (milliseconds since epoch) into a formatted timestamp string `"MM/dd HH:mm"`.
 *
 * ### Example
 * ```kotlin
 * val timestamp = System.currentTimeMillis().toTimestamp
 * println(timestamp) // "10/18 15:45"
 * ```
 */
val Long.toTimestamp: String get() = toTimestampRoot

/**
 * Formats this ISO-8601 date-time [String] into `"HH:mm"`.
 *
 * The string must represent a valid [kotlin.time.Instant].
 *
 * ### Example
 * ```kotlin
 * val formatted = "2025-10-18T14:05:00Z".toTimestampHourMin
 * println(formatted) // "14:05"
 * ```
 */
val String.toTimestampHourMin: String get() = toTimestampHourMinAMPMRoot

/**
 * Converts this [Long] value (milliseconds since epoch) into a timestamp string
 * including the day of the week.
 *
 * Format: `"EEE, MM/dd HH:mm"`
 * Example output: `"SAT, 10/18 14:30"`
 *
 * ### Example
 * ```kotlin
 * val timestamp = System.currentTimeMillis().toTimestampWithDays
 * println(timestamp) // "SAT, 10/18 14:30"
 * ```
 */
val Long.toTimestampWithDays: String get() = toTimestampWithDaysRoot

/**
 * Converts this [Long] value (milliseconds since epoch) into a timestamp string
 * including the full year.
 *
 * Format: `"yyyy/MM/dd HH:mm"`
 * Example output: `"2025/10/18 14:30"`
 *
 * ### Example
 * ```kotlin
 * val timestamp = System.currentTimeMillis().toTimestampYear
 * println(timestamp) // "2025/10/18 14:30"
 * ```
 */
val Long.toTimestampYear: String get() = toTimestampYearRoot

/**
 * Formats this [Long] duration in milliseconds into a readable `"HH:mm:ss"` style string.
 *
 * Automatically omits hours or minutes when zero for compactness.
 * - `65_000L` → `"01:05"`
 * - `3_650_000L` → `"01:00:50"`
 *
 * ### Example
 * ```kotlin
 * val formatted = 3_650_000L.formatMillisecondsToHours
 * println(formatted) // "01:00:50"
 * ```
 */
val Long.formatMillisecondsToHours: String get () = formatMillisecondsToHoursRoot

/**
 * Formats this [Long] duration in milliseconds into a full `"HH:mm:ss"` string.
 *
 * Ensures that minutes and seconds are always displayed as two digits.
 * Hours are optional — omitted if zero.
 *
 * - `65_000L` → `"01:05"`
 * - `3_650_000L` → `"01:00:50"`
 * - `10_000L` → `"00:10"`
 *
 * ### Example
 * ```kotlin
 * val duration = 3_650_000L.fullFormatMillisecondsToHours
 * println(duration) // "01:00:50"
 * ```
 */
val Long.fullFormatMillisecondsToHours: String get () = fullFormatMillisecondsToHoursRoot

/**
 * Suspends execution until the specified [targetTime] is reached, then invokes [onTimeReached].
 *
 * Runs on [kotlinx.coroutines.Dispatchers.Default] and uses an internal delay based on the difference between
 * the current system time and the [targetTime].
 *
 * @param targetTime The [kotlinx.datetime.LocalDateTime] to wait for.
 * @param onTimeReached Callback invoked once the system time reaches [targetTime].
 *
 * ### Example
 * ```kotlin
 * val target = Clock.System.now()
 *     .plus(1, DateTimeUnit.HOUR)
 *     .toLocalDateTime(TimeZone.currentSystemDefault())
 *
 * observeSpecificTime(target) {
 *     println("The target time has been reached!")
 * }
 * ```
 */
suspend fun observeSpecificTime(targetTime: LocalDateTime, onTimeReached: () -> Unit) = observeSpecificTimeRoot(targetTime, onTimeReached)

/**
 * Suspends execution and triggers [onTimeReached] approximately at the start of the next hour.
 *
 * Calculates the upcoming hour based on the current system time, then delays execution
 * before invoking [onTimeReached].
 * Currently, the function waits for a fixed **20 seconds (20,000 ms)** instead of the exact
 * duration until the next hour — adjust the delay logic if precise timing is required.
 *
 * Runs on [kotlinx.coroutines.Dispatchers.Default].
 *
 * @param onTimeReached Callback invoked when the next hour is (approximately) reached.
 *
 * ### Example
 * ```kotlin
 * observeNextHour {
 *     println("The new hour just started!")
 * }
 * ```
 */
suspend fun observeNextHour(onTimeReached: () -> Unit) = observeNextHourRoot(onTimeReached)