@file:Suppress("unused")

package com.kotlin.composesturdy.global.util

import android.content.Context
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.kotlin.sturdy.global.util.checkActivityRecognitionRoot
import com.kotlin.sturdy.global.util.checkAndRequestMediaPermissionsRoot
import com.kotlin.sturdy.global.util.checkLocationPermissionRoot
import com.kotlin.sturdy.global.util.hasExternalReadPermissionRoot
import com.kotlin.sturdy.global.util.hasExternalReadWritePermissionRoot
import com.kotlin.sturdy.global.util.hasNotificationPermissionRoot
import com.kotlin.sturdy.global.util.hasVoicePermissionRoot
import com.kotlin.sturdy.global.util.isCanWriteSettingRoot
import com.kotlin.sturdy.global.util.isNotificationPolicyAccessGrantedRoot

/**
 * Checks whether the app has permission to post notifications.
 *
 * - On Android 13 (Tiramisu) and above, explicitly checks the [android.Manifest.permission.POST_NOTIFICATIONS].
 * - On lower API levels, always returns `true` since no permission is required.
 *
 * @return `true` if the app has notification permission, otherwise `false`.
 */
inline val Context.hasNotificationPermission: Boolean
    get() = hasNotificationPermissionRoot

/**
 * Checks whether the app has access to modify the system's Do Not Disturb (DND) policy.
 *
 * @return `true` if notification policy access is granted, otherwise `false`.
 */
inline val Context.isNotificationPolicyAccessGranted: Boolean
    get() = isNotificationPolicyAccessGrantedRoot

/**
 * Verifies if the app has location permissions (fine or coarse).
 *
 * - If permissions are granted, executes [invoke].
 * - If not, triggers [failed] with the required permissions array.
 *
 * @param invoke Called when location permissions are granted.
 * @param failed Called when location permissions are missing; receives an array of required permissions.
 */
inline fun Context.checkLocationPermission(
    invoke: () -> Unit,
    failed: (Array<String>) -> Unit
) = checkLocationPermissionRoot(invoke, failed)

/**
 * Checks and requests the necessary media storage permissions for this [androidx.appcompat.app.AppCompatActivity].
 *
 * - On Android 13 (Tiramisu) and above, it requests [android.Manifest.permission.READ_MEDIA_IMAGES] and [android.Manifest.permission.READ_MEDIA_VIDEO].
 * - On lower API levels, it requests [android.Manifest.permission.READ_EXTERNAL_STORAGE].
 * - On Android 14 (Upside Down Cake) and above, it also considers whether the app has partial access
 *   through persisted URI permissions (e.g., user-selected folders via the photo picker).
 *
 * @param onResult A callback invoked after permission handling:
 *  - `granted`: `true` if all permissions are granted.
 *  - `partialAccess`: `true` if partial access exists through persisted URI permissions.
 */
fun AppCompatActivity.checkAndRequestMediaPermissions(
    onResult: (granted: Boolean, partialAccess: Boolean) -> Unit
) = checkAndRequestMediaPermissionsRoot(onResult)

/**
 * Checks whether the app has permission to read and write to external storage.
 *
 * - On Android 11 (R) and above, checks [android.os.Environment.isExternalStorageManager].
 * - On lower API levels, verifies both [android.Manifest.permission.READ_EXTERNAL_STORAGE] and [android.Manifest.permission.WRITE_EXTERNAL_STORAGE].
 *
 * @return `true` if the app can fully access external storage, otherwise `false`.
 */
inline val Context.hasExternalReadWritePermission: Boolean
    get() = hasExternalReadWritePermissionRoot

/**
 * Checks whether the app has permission to read media files from external storage.
 *
 * - On Android 13 (Tiramisu) and above, verifies both [android.Manifest.permission.READ_MEDIA_IMAGES]
 *   and [android.Manifest.permission.READ_MEDIA_VIDEO].
 * - On Android 11 (R) and 12 (S), checks [android.os.Environment.isExternalStorageManager].
 * - On lower API levels, validates traditional read/write storage permissions.
 *
 * @return `true` if the app can read external storage media, otherwise `false`.
 */
inline val Context.hasExternalReadPermission: Boolean
    get() = hasExternalReadPermissionRoot

/**
 * Checks whether the app has permission to record audio using the device's microphone.
 *
 * @return `true` if [android.Manifest.permission.RECORD_AUDIO] is granted, otherwise `false`.
 */
inline val Context.hasVoicePermission: Boolean
    get() = hasVoicePermissionRoot

/**
 * Checks whether the app has permission to access physical activity or body sensor data.
 *
 * - On Android 10 (Q) and above, this verifies [android.Manifest.permission.ACTIVITY_RECOGNITION].
 * - It also considers [android.Manifest.permission.BODY_SENSORS] as a valid alternative.
 *
 * Executes [invoke] if permission is granted; otherwise, triggers [failed] with the required permissions.
 *
 * @param invoke Called when activity recognition or body sensor permissions are granted.
 * @param failed Called when permissions are missing; receives the required permissions array.
 */
@RequiresApi(Build.VERSION_CODES.Q)
inline fun Context.checkActivityRecognition(
    invoke: () -> Unit,
    failed: (Array<String>) -> Unit
) = checkActivityRecognitionRoot(invoke, failed)

/**
 * Checks whether the app has permission to modify system settings (e.g., brightness, volume).
 *
 * @return `true` if the app can write to system settings, otherwise `false`.
 */
inline val Context.isCanWriteSetting: Boolean
    get() = isCanWriteSettingRoot
