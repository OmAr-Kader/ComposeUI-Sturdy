@file:Suppress("unused")

package com.kotlin.composesturdy.global.util

import android.content.Context
import androidx.camera.core.ImageCapture
import androidx.camera.view.PreviewView
import androidx.lifecycle.LifecycleOwner
import com.kotlin.sturdy.global.util.CameraManagerRoot
import com.kotlin.sturdy.global.util.taskPhotoRoot
import java.io.File

/**
 * Coordinates CameraX preview and capture operations through suspend-friendly APIs.
 *
 * Camera binding and capture are serialized internally, so callers can safely invoke
 * public methods from different coroutines without racing camera state.
 *
 * @param context Any context used to obtain an application context for CameraX.
 */
class CameraManager(
    context: Context
) {
    val root = CameraManagerRoot(context)
    /** Currently active lens direction used for preview and capture. */
    val lensFacing: LensDirection
        get() = LensDirection.entries.firstOrNull { it.cameraSelectorValue == root.lensFacing } ?: LensDirection.UNKNOWN

    /**
     * Starts camera preview and binds capture use cases to [lifecycleOwner].
     *
     * @param lifecycleOwner Owner controlling camera lifecycle binding.
     * @param previewView View that renders the camera preview stream.
     * @param lensFacing Lens direction to bind. Defaults to the current lens.
     * @return Success when binding completes, failure when CameraX setup fails.
     */
    suspend fun startPreview(
        lifecycleOwner: LifecycleOwner,
        previewView: PreviewView,
        lensFacing: Int = root.activeLensFacing
    ): Result<Unit> = root.startPreview(lifecycleOwner, previewView, lensFacing)

    /**
     * Switches between front and back camera, then rebinds preview/capture use cases.
     *
     * @param lifecycleOwner Owner controlling camera lifecycle binding.
     * @param previewView View that renders the camera preview stream.
     * @return Success with the newly active lens direction, or failure if rebinding fails.
     */
    suspend fun switchCamera(
        lifecycleOwner: LifecycleOwner,
        previewView: PreviewView
    ): Result<Int> = root.switchCamera(lifecycleOwner, previewView)

    /**
     * Captures a photo and writes it to [outputFile].
     *
     * @param outputFile Destination file for the captured image.
     * @return Success with [outputFile], or failure when capture cannot complete.
     */
    suspend fun capturePhoto(outputFile: File): Result<File> = root.capturePhoto(outputFile)

    /**
     * Stops preview by unbinding all camera use cases.
     */
    suspend fun stopPreview() = root.stopPreview()

    /**
     * Releases camera resources and shuts down the internal capture executor.
     */
    fun release() = root.release()
}

/** Enum representing camera lens directions with corresponding CameraX selector values. */
enum class LensDirection(val cameraSelectorValue: Int) {
    BACK(androidx.camera.core.CameraSelector.LENS_FACING_BACK),
    FRONT(androidx.camera.core.CameraSelector.LENS_FACING_FRONT),
    UNKNOWN(androidx.camera.core.CameraSelector.LENS_FACING_UNKNOWN);
}

/**
 * Captures a photo using callback-style success/failure handlers.
 *
 * @param photoFile Destination file. Existing content is deleted before capture.
 * @param invoke Called with [photoFile] when capture succeeds.
 * @param failed Called when capture fails.
 */
fun ImageCapture.taskPhoto(photoFile: File, invoke: (File) -> Unit, failed: () -> Unit) = taskPhotoRoot(photoFile, invoke, failed)