@file:Suppress("unused")

package com.kotlin.composesturdy.global.util

import android.content.Context
import android.net.Uri
import com.kotlin.sturdy.global.util.getPathRoot

/**
 * Attempts to resolve the absolute file system path from the given [Uri].
 *
 * This function tries multiple decoding and fallback strategies to obtain
 * a valid file path, including checking both `path` and `encodedPath`.
 *
 * @param uri The [Uri] representing the file.
 * @return The resolved absolute file path as a [String].
 *
 * ### Example
 * ```kotlin
 * val uri: Uri = ...
 * val path = context.getPath(uri)
 * println("File path: $path")
 * ```
 *
 */
suspend fun Context.getPath(uri: Uri): String = getPathRoot(uri)
