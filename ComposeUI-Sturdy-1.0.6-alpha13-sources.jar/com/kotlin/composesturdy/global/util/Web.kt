@file:Suppress("unused")

package com.kotlin.composesturdy.global.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkRequest
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.core.content.ContextCompat
import com.kotlin.sturdy.global.util.NetworkObserverEndAtDisposeRoot
import com.kotlin.sturdy.global.util.fetchConnectivityManagerRoot
import com.kotlin.sturdy.global.util.fetchNetworkObserverRoot
import com.kotlin.sturdy.global.util.isNetworkAvailableRoot

/**
 * Observes network connectivity changes and automatically unregisters the callback when the composable
 * leaves the composition.
 *
 * This composable registers a [ConnectivityManager.NetworkCallback] to monitor network availability
 * and loss events. The callback is automatically unregistered in the [DisposableEffect]'s `onDispose`
 * block to prevent memory leaks.
 *
 * @param onAvailable Callback invoked when a network becomes available. This occurs when a network
 * connection is established and has internet capability.
 * @param onLost Callback invoked when a network is lost. This occurs when a previously available
 * network connection is disconnected.
 *
 * @see ConnectivityManager.NetworkCallback
 * @see NetworkRequest
 * @see DisposableEffect
 *
 * Example usage:
 * ```
 * NetworkObserverEndAtDispose(
 *     onAvailable = {
 *         // Handle network available
 *         viewModel.refreshData()
 *     },
 *     onLost = {
 *         // Handle network lost
 *         showOfflineMessage()
 *     }
 * )
 * ```
 *
 * Note: The network callbacks log events internally but do not invoke the provided lambda callbacks.
 * Consider calling [onAvailable] and [onLost] within the respective callback methods if you need
 * to react to these events.
 */
@Composable
fun NetworkObserverEndAtDispose(onAvailable: () -> Unit, onLost: () -> Unit) = NetworkObserverEndAtDisposeRoot(onAvailable, onLost)

/**
 * Creates and registers a network observer that monitors connectivity changes.
 *
 * This extension function creates a [ConnectivityManager.NetworkCallback] that monitors network
 * availability and loss events, then registers it with the [ConnectivityManager]. The callback
 * monitors networks with internet capability.
 *
 * **Important:** The returned [ConnectivityManager.NetworkCallback] must be unregistered by calling
 * [ConnectivityManager.unregisterNetworkCallback] when no longer needed to prevent memory leaks.
 *
 * @param onAvailable Callback invoked when a network becomes available. This occurs when a network
 * connection is established and has internet capability.
 * @param onLost Callback invoked when a network is lost. This occurs when a previously available
 * network connection is disconnected.
 *
 * @return The registered [ConnectivityManager.NetworkCallback] instance. Must be unregistered
 * when no longer needed.
 *
 * @see ConnectivityManager.registerNetworkCallback
 * @see ConnectivityManager.unregisterNetworkCallback
 * @see NetworkRequest
 *
 * Example usage:
 * ```
 * val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
 * val networkCallback = connectivityManager.fetchNetworkObserver(
 *     onAvailable = {
 *         // Handle network available
 *         syncData()
 *     },
 *     onLost = {
 *         // Handle network lost
 *         pauseDownloads()
 *     }
 * )
 *
 * // Later, when done:
 * connectivityManager.unregisterNetworkCallback(networkCallback)
 * ```
 *
 * Note: The network callbacks log events internally but do not invoke the provided lambda callbacks.
 * Consider calling [onAvailable] and [onLost] within the respective callback methods if you need
 * to react to these events.
 */
fun ConnectivityManager.fetchNetworkObserver(
    onAvailable: () -> Unit, onLost: () -> Unit
): ConnectivityManager.NetworkCallback = fetchNetworkObserverRoot(onAvailable, onLost)

/**
 * Retrieves the [ConnectivityManager] instance safely using [ContextCompat.getSystemService].
 * Falls back to the legacy [Context.getSystemService] call if necessary.
 */
val Context.fetchConnectivityManager: ConnectivityManager
    get() = fetchConnectivityManagerRoot

/**
 * Checks whether the device currently has an active internet connection.
 *
 * It verifies connectivity across multiple transport types:
 * - Wi-Fi
 * - Cellular
 * - Ethernet
 * - Bluetooth
 *
 * @return `true` if the device is connected to a network; otherwise `false`.
 */
fun Context.isNetworkAvailable(): Boolean = isNetworkAvailableRoot()