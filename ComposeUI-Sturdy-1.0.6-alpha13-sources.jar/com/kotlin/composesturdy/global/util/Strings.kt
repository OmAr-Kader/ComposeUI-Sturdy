@file:Suppress("unused")

package com.kotlin.composesturdy.global.util

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.provider.Settings
import android.text.TextUtils
import android.util.Patterns
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import com.kotlin.sturdy.global.util.copyToClipBoardRoot
import com.kotlin.sturdy.global.util.firstCapitalRoot
import com.kotlin.sturdy.global.util.firstSpaceRoot
import com.kotlin.sturdy.global.util.isValidEmailRoot
import com.kotlin.sturdy.global.util.needDeviceIdRoot
import com.kotlin.sturdy.global.util.toPriceRoot
import com.kotlin.sturdy.global.util.toSecureUrlRoot
import java.net.MalformedURLException
import java.net.URL
import java.text.NumberFormat
import java.util.Locale

@Deprecated("This property is a placeholder and does not generate unique IDs. Implement a proper unique ID generator as needed.")
val generateUniqueId: String get() = ""

/**
 * Returns true when this string is non-empty and matches Android's email pattern.
 */
inline val String.isValidEmail: Boolean get() = isValidEmailRoot

/**
 * Returns the substring from the start of this string up to the first space character.
 *
 * If no space is found, returns the entire string.
 */
@get:ReadOnlyComposable
@get:Composable
inline val String.firstSpace: String
    get() = firstSpaceRoot

/**
 * Returns a copy of this string with the first character converted to uppercase.
 *
 * Other characters remain unchanged.
 */
@get:ReadOnlyComposable
@get:Composable
inline val String.firstCapital: String
    get() = firstCapitalRoot

/**
 * Retrieves the unique device ID (Android ID) for this device.
 *
 * @return The device's Android ID as a [String].
 */
@SuppressLint("HardwareIds")
fun Context.needDeviceId(): String = needDeviceIdRoot()

/**
 * Copies the current string value to the system clipboard.
 *
 * @param context The [Context] used to access the clipboard service.
 */
fun String.copyToClipBoard(context: Context) = copyToClipBoardRoot(context)

/**
 * Converts this string into a secure [URL].
 *
 * - Returns `null` if the URL uses the insecure "http" scheme.
 * - Attempts to prepend "https://" if the initial value is malformed.
 *
 * @return A valid secure [URL], or `null` if conversion fails.
 */
fun String.toSecureUrl(): URL? = toSecureUrlRoot()

/**
 * Formats this [Double] value as a price or number string.
 *
 * @param locale The [Locale] used for number formatting (default: [Locale.US]).
 * @param withSymbol Whether to include the currency symbol in the formatted string.
 * @return A localized, formatted price string with two decimal places.
 */
fun Double.toPrice(locale: Locale = Locale.US, withSymbol: Boolean = false): String = toPriceRoot(locale, withSymbol)