@file:Suppress("unused")

package com.kotlin.composesturdy.global.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kotlin.sturdy.global.ui.DeviceModeRoot
import com.kotlin.sturdy.global.ui.DynamicRoot
import com.kotlin.sturdy.global.ui.ScreenConfigRoot
import com.kotlin.sturdy.global.ui.rememberScreenConfigRoot

/**
 * Dynamically arranges two composables based on screen orientation.
 * In portrait mode, stacks them vertically in a Column.
 * In landscape mode, places them side-by-side in separate Columns within a Row.
 *
 * @param isLandscape Whether the screen is in landscape orientation
 * @param horizontalAlignment Horizontal alignment for portrait mode and inner columns in landscape
 * @param verticalArrangement Vertical arrangement for portrait mode and inner columns in landscape
 * @param verticalAlignment Vertical alignment for landscape mode Row
 * @param horizontalArrangement Horizontal arrangement for landscape mode Row
 * @param upper The composable to display first (top in portrait, left in landscape)
 * @param lower The composable to display second (bottom in portrait, right in landscape)
 *
 * Example:
 * ```
 * Dynamic(
 *     isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
 * ) {
 *     Text("Header")
 * } {
 *     Button(onClick = {}) { Text("Action") }
 * }
 * ```
 */
@Composable
inline fun Dynamic(
    isLandscape: Boolean,
    horizontalAlignment: Alignment.Horizontal = Alignment.CenterHorizontally,
    verticalArrangement: Arrangement.Vertical = Arrangement.Center,
    verticalAlignment: Alignment.Vertical = Alignment.CenterVertically,
    horizontalArrangement: Arrangement.Horizontal = Arrangement.Center,
    upper: @Composable ColumnScope.() -> Unit,
    lower: @Composable ColumnScope.() -> Unit
) = DynamicRoot(
    isLandscape = isLandscape,
    horizontalAlignment = horizontalAlignment,
    verticalArrangement = verticalArrangement,
    verticalAlignment = verticalAlignment,
    horizontalArrangement = horizontalArrangement,
    upper = upper,
    lower = lower)

/**
 * Remembers and tracks the current screen configuration, including device type,
 * scale ratio, and orientation.
 *
 * Automatically updates when the window size changes (e.g., screen rotation, split-screen).
 * The ratio adjusts UI scaling based on screen width to maintain consistent sizing across devices.
 *
 * @return [ScreenConfigRoot] containing the current device mode, scale ratio, and orientation
 *
 * Example:
 * ```
 * @Composable
 * fun MyScreen() {
 *     val screenConfig = rememberScreenConfig()
 *
 *     Text(
 *         text = "Hello",
 *         fontSize = screenConfig.sp(16),
 *         modifier = Modifier.padding(screenConfig.dp(8))
 *     )
 *
 *     if (screenConfig.mode == ScreenConfig.MODE_TABLET) {
 *         // Show tablet-specific layout
 *     }
 * }
 * ```
 */
@Composable
fun rememberScreenConfig(): ScreenConfigRoot = rememberScreenConfigRoot()


/**
 * Holds screen configuration data including device type, scale ratio, and orientation.
 *
 * Use [sp] and [dp] extension functions to scale text and dimensions based on screen size.
 *
 * @property ScreenConfigRoot.mode The device type (wear, phone, tablet, split-screen, or desktop)
 * @property ScreenConfigRoot.ratio Scale multiplier for responsive sizing (typically 0.9 to 1.5)
 * @property ScreenConfigRoot.isLandscape Whether the screen is in landscape orientation
 */
typealias ScreenConfig = ScreenConfigRoot

typealias DeviceMode = DeviceModeRoot