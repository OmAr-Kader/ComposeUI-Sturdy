@file:Suppress("unused", "UNUSED_PARAMETER")

package com.kotlin.composesturdy.global.ui

import androidx.annotation.FloatRange
import androidx.compose.animation.AnimatedContentScope
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.core.InfiniteRepeatableSpec
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.FloatingActionButtonElevation
import androidx.compose.material3.contentColorFor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kotlin.composesturdy.global.util.imageBuildr
import com.kotlin.sturdy.global.ui.*

/**
 * Animates between a shimmer placeholder and actual content in a Row layout.
 * Shows shimmer when value is null, fades to content when value is available.
 */
@Composable
fun <T> AnimatedShimmerRowContent(
    value: T?,
    shimmer: @Composable RowScope.() -> Unit,
    content: @Composable RowScope.(T) -> Unit
) = AnimatedShimmerRowContentRoot(
    value = value,
    shimmer = shimmer,
    content = content
)

/**
 * Animates between a shimmer placeholder and actual content in a Column layout.
 * Shows shimmer when value is null, fades to content when value is available.
 */
@Composable
fun <T> AnimatedShimmerColumnContent(
    value: T?,
    shimmer: @Composable ColumnScope.() -> Unit,
    content: @Composable ColumnScope.(T) -> Unit
) = AnimatedShimmerColumnContentRoot(
    value = value,
    shimmer = shimmer,
    content = content
)

/**
 * Displays an image loaded from a URL with optional rounded corners, loading states, and fade-in animation.
 *
 * This composable loads and displays an image using Coil3's [coil3.compose.SubcomposeAsyncImage] within a fixed-size
 * container. Successfully loaded images fade in with an animation and can have custom rounded corners.
 * The image is displayed with crop scaling to fill the available space.
 *
 * @param imageUri The URL or path of the image to be loaded.
 * @param size The size ([Dp]) to apply to both width and height of the image container.
 * @param corner Optional [RoundedCornerShape] to apply rounded corners to the image. If null,
 * the image will have sharp corners.
 * @param loadingAndError Optional composable to display during image loading or error states.
 * Receives a [Boolean] parameter (currently always `true`). If null, default Coil loading/error
 * behavior is used. When provided for loading, a shimmer effect is automatically applied.
 *
 * @see coil3.compose.SubcomposeAsyncImage
 * @see AnimatedFadeOnce
 * @see androidx.compose.ui.layout.ContentScale.Crop
 *
 * Example usage:
 * ```
 * ImageForCurveImageUrl(
 *     imageUri = "https://example.com/image.jpg",
 *     size = 120.dp,
 *     corner = RoundedCornerShape(16.dp),
 *     loadingAndError = { isLoading ->
 *         if (isLoading) {
 *             CircularProgressIndicator(modifier = Modifier.size(40.dp))
 *         }
 *     }
 * )
 * ```
 *
 * Example with no rounded corners:
 * ```
 * ImageForCurveImageUrl(
 *     imageUri = profileImageUrl,
 *     size = 80.dp,
 *     corner = null
 * )
 * ```
 *
 * Note:
 * - Images are loaded using [android.content.Context.imageBuildr] extension function.
 * - Successfully loaded images fade in over 200ms using [AnimatedFadeOnce].
 * - Errors are logged with the tag "ImageForCurveImageUrl".
 * - [androidx.compose.ui.graphics.FilterQuality.None] is used for performance optimization.
 */
@Composable
fun ImageForCurveImageUrl(
    imageUri: String,
    size: Dp,
    corner: RoundedCornerShape? = null,
    loadingAndError: @Composable ((Boolean) -> Unit)? = null,
) = ImageForCurveImageUrlRoot(
    imageUri = imageUri,
    size = size,
    corner = corner,
    loadingAndError = loadingAndError
)

/**
 * Displays a video thumbnail loaded from a URL with rounded corners and fade-in animation.
 * Extracts and displays a frame from the video file using VideoFrameDecoder.
 *
 * @param imageUri The URL or path of the video file
 * @param size The size of the thumbnail container
 */
@Composable
fun ImageForCurveVideoUrl(
    imageUri: String,
    size: Dp,
) = ImageForCurveVideoUrlRoot(
    imageUri = imageUri,
    size = size
)

/**
 * Animates between a shimmer placeholder and actual content in a Box layout.
 * Shows shimmer when value is null, fades to content when value is available.
 */
@Composable
fun <T> AnimatedShimmerBoxContent(
    value: T?,
    shimmer: @Composable BoxScope.() -> Unit,
    content: @Composable BoxScope.(T) -> Unit
) = AnimatedShimmerBoxContentRoot(
    value = value,
    shimmer = shimmer,
    content = content
)


/**
 * Creates an animated shimmer loading effect with a moving gradient.
 */
@Composable
fun Modifier.shimmerEffect(
    isLoading: Boolean = true,
    widthOfShadowBrush: Int = 500,
    animationSpec: InfiniteRepeatableSpec<Float> = infiniteRepeatable(
        animation = tween(
            durationMillis = 1500,
            easing = LinearEasing,
        ),
        repeatMode = RepeatMode.Reverse
    ),
    gradientColors: List<Color> = listOf(
        Color.LightGray.copy(alpha = 0.3f), // Shimmer highlight
        Color.LightGray.copy(alpha = 0.3f), // Shimmer highlight
        Color.Transparent,
    ),
): Modifier = shimmerEffectRoot(
    isLoading = isLoading,
    widthOfShadowBrush = widthOfShadowBrush,
    animationSpec = animationSpec,
    gradientColors = gradientColors
)

/**
 * Applies size based on width value: 0.dp = fillMaxWidth, -1.dp = wrapContent, otherwise = exact size.
 */
fun Modifier.fillWidthIfZero(size: DpSize) = fillWidthIfZeroRoot(size)

/**
 * Makes composable clickable without ripple effect.
 */
@Composable
fun Modifier.noRippleClickable(onClick: () -> Unit): Modifier = noRippleClickableRoot(onClick)


/**
 * Applies [Modifier.fillMaxSize] only when [value] is true.
 */
fun Modifier.fillMaxSizeIf(value: Boolean): Modifier = fillMaxSizeIfRoot(value)

/**
 * Supported slide directions used by [slideTransition]
 * Cases [TransitionDirectionRoot.UP], [TransitionDirectionRoot.DOWN], [TransitionDirectionRoot.START], [TransitionDirectionRoot.END].
 */
typealias TransitionDirection = TransitionDirectionRoot

/**
 * Wrapper around AnimatedContent with caller-provided transition behavior.
 *
 * @param targetState State that drives content changes.
 * @param transitionSpec Enter/exit transition used between states.
 * @param modifier Modifier applied to the AnimatedContent container.
 * @param content Composable rendered for each state.
 */
@Composable
fun <S> AnimationChangeContent(
    targetState: S,
    transitionSpec: AnimatedContentTransitionScope<S>.() -> ContentTransform,
    modifier: Modifier = Modifier,
    content: @Composable AnimatedContentScope.(targetState: S) -> Unit,
) = AnimationChangeContentRoot(
    targetState = targetState,
    transitionSpec = transitionSpec,
    modifier = modifier,
    content = content
)

/**
 * Returns a remembered slide-and-fade transition based on [direction].
 *
 * @param direction Direction used for enter and exit offsets.
 */
@Composable
fun <S> slideTransition(direction: TransitionDirection = TransitionDirectionRoot.DOWN): AnimatedContentTransitionScope<S>.() -> ContentTransform =
    slideTransitionRoot(direction)

/**
 * Keeps the hosting Activity screen on while this composable is in composition.
 */
@Composable
fun KeepScreenOn() = KeepScreenOnRoot()

/**
 * Sets status bar color and icon appearance for the current window.
 *
 * @param color Target status bar color.
 * @param reset When true, restores previous status bar settings on dispose.
 */
@Composable
fun SetStatusBarColor(color: Color, reset: Boolean = false) = SetStatusBarColorRoot(color, reset)

/**
 * Makes the status bar transparent and updates status bar icon contrast.
 *
 * @param darkIcons True to use dark status bar icons, false for light icons.
 */
@Composable
fun TransparentStatusBar(darkIcons: Boolean) = TransparentStatusBarRoot(darkIcons)

/**
 * Returns true if device is in portrait orientation.
 */
@Composable
fun isPortraitMode(): Boolean = isPortraitModeRoot()

/**
 * Returns a State indicating whether the keyboard is currently visible.
 */
@Composable
fun keyboardAsState(): State<Boolean> = keyboardAsStateRoot()

/**
 * Executes the given function once when the composable is first launched.
 */
@Composable
fun OnLaunchScreen(invoke: () -> Unit) = OnLaunchScreenRoot(invoke)

/**
 * Displays a fullscreen loading overlay with a circular progress indicator.
 */
@Composable
fun LoadingScreen(
    isLoading: Boolean,
    circle: Color,
    background: Color = Color(50, 50, 50).copy(alpha = 0.5F)
) = LoadingScreenRoot(isLoading, circle, background)

/**
 * Wraps content with an optional loading overlay that blurs the content and shows a progress indicator.
 */
@Composable
fun ScreenLoading(
    isLoading: Boolean,
    circle: Color,
    background: Color = Color(50, 50, 50).copy(alpha = 0.5F),
    content: @Composable () -> Unit,
) = ScreenLoadingRoot(isLoading, circle, background, content)

/**
 * Animates text changes with a fade transition between states.
 */
@Composable
fun <S> AnimatedText(
    targetState: S,
    content: @Composable AnimatedContentScope.(targetState: S) -> Unit
) = AnimatedTextRoot(targetState, content)

/**
 * Animates content with a scale-up effect on initial composition.
 * The content scales from 0.25 to 1.0 once when first displayed.
 *
 * @param modifier Modifier to be applied to the container
 * @param contentAlignment Alignment of content within the box, defaults to center
 * @param duration Animation duration in milliseconds, defaults to 100ms
 * @param label Label for the animation used for debugging
 * @param content Composable content to be animated
 */
@Composable
fun AnimatedExpandOnce(
    modifier: Modifier = Modifier,
    contentAlignment: Alignment = Alignment.Center,
    duration: Int = 100,
    label: String,
    content: @Composable BoxScope.() -> Unit
) = AnimatedExpandOnceRoot(modifier, contentAlignment, duration, label, content)

/**
 * Animates content with a fade-in effect on initial composition.
 * The content fades from transparent to fully visible once when first displayed.
 *
 * @param modifier Modifier to be applied to the container
 * @param contentAlignment Alignment of content within the box, defaults to center
 * @param duration Animation duration in milliseconds, defaults to 100ms
 * @param label Label for the animation used for debugging
 * @param content Composable content to be animated
 */
@Composable
fun AnimatedFadeOnce(
    modifier: Modifier = Modifier,
    contentAlignment: Alignment = Alignment.Center,
    duration: Int = 100,
    label: String,
    content: @Composable BoxScope.() -> Unit
) = AnimatedFadeOnceRoot(modifier, contentAlignment, duration, label, content)

/**
 * Animates content with a slide-in effect on initial composition.
 * The content slides from the specified offset to its final position once when first displayed.
 *
 * @param modifier Modifier to be applied to the container
 * @param durationMillis Animation duration in milliseconds, defaults to 100ms
 * @param offsetY Initial vertical offset to slide from, defaults to -100.dp (from top)
 * @param label Label for the animation used for debugging
 * @param content Composable content to be animated
 */
@Composable
fun AnimatedSlideInOnce(
    modifier: Modifier = Modifier,
    durationMillis: Int = 100,
    offsetY: Dp = (-100).dp,
    label: String,
    content: @Composable () -> Unit
) = AnimatedSlideInOnceRoot(modifier, durationMillis, offsetY, label, content)

/**
 * A rounded card button with customizable size, colors, and text.
 */
@Composable
fun CardButton(
    onClick: (() -> Unit),
    text: String,
    width: Dp = 80.dp,
    height: Dp = 30.dp,
    curve: Dp = height / 2,
    fontSize: TextUnit = 11.sp,
    color: Color,
    textColor: Color
) = CardButtonRoot(onClick, text, width, height, curve, fontSize, color, textColor)

/**
 * A back button with a card background and elevation effect.
 *
 * @param cardColor The background color of the card container
 * @param color The color of the back arrow icon
 * @param onClick Callback invoked when the button is clicked
 */
@Composable
fun BackButton(cardColor: Color, color: Color, onClick: () -> Unit) = BackButtonRoot(cardColor, color, onClick)

/**
 * A minimal back button without card background or elevation.
 *
 * @param color The color of the back arrow icon
 * @param onClick Callback invoked when the button is clicked
 */
@Composable
fun BackButtonLess(color: Color, onClick: () -> Unit) = BackButtonLessRoot(color, onClick)

/**
 * A horizontally scrollable bar with customizable background and height.
 *
 * @param background The background color of the bar
 * @param height The height of the bar, defaults to 56.dp
 * @param content The composable content to be displayed within the bar
 */
@Composable
fun ScrollableBar(
    background: Color,
    height: Dp = 56.dp,
    content: @Composable (() -> Unit),
) = ScrollableBarRoot(background, height, content)

/**
 * A loading indicator bar that displays a progress indicator or colored spacer.
 *
 * @param isLoading Whether to show the loading progress indicator
 * @param color The color of the progress indicator or spacer
 * @param subScreen Whether to show colored spacer when not loading, defaults to true
 */
@Composable
fun LoadingBar(isLoading: Boolean, color: Color, subScreen: Boolean = true) =
    LoadingBarRoot(isLoading, color, subScreen)

/**
 * A scrollable list that displays items with click handling.
 *
 * @param D The type of data in the list
 * @param list The list of items to display
 * @param bodyClick Callback invoked when an item is clicked, receives the clicked item
 * @param additionalItem Optional composable to display at the top of the list
 * @param content Composable function to render each list item
 */
@Composable
fun <D> ListBody(
    list: List<D>,
    bodyClick: (D) -> Unit,
    additionalItem: (@Composable () -> Unit)? = null,
    content: @Composable (D) -> Unit,
) = ListBodyRoot(list, bodyClick, additionalItem, content)

/**
 * A scrollable list for displaying editable items without click handling.
 *
 * @param D The type of data in the list
 * @param list The list of items to display
 * @param additionalItem Optional composable to display at the top of the list
 * @param itemColor The background color of each item, defaults to transparent
 * @param content Composable function to render each list item
 */
@Composable
fun <D> ListBodyEdit(
    list: List<D>,
    additionalItem: (@Composable () -> Unit)? = null,
    itemColor: Color = Color.Transparent,
    content: @Composable (D) -> Unit,
) = ListBodyEditRoot(list, additionalItem, itemColor, content)

/**
 * A customizable rating bar that displays stars to represent a rating value.
 * Supports fractional ratings, custom star content, and optional user interaction.
 *
 * @param rating The current rating value to display
 * @param modifier Modifier to be applied to the rating bar
 * @param ratingStep The step size for rating increments, between 0.0 and 1.0
 * @param starsCount The total number of stars to display, defaults to 5
 * @param starSize The size of each star, defaults to 32.dp
 * @param starSpacing The spacing between stars, defaults to 0.dp
 * @param onRate Callback invoked when a star is clicked, receives the new rating value. If null, rating is read-only
 * @param unratedContent Composable content for unrated (empty) stars
 * @param ratedContent Composable content for rated (filled) stars
 * @param enableDragging Whether to enable drag gestures for rating
 * @param enableTapping Whether to enable tap gestures for rating
 */
@Composable
fun RatingBar(
    rating: Float,
    modifier: Modifier = Modifier,
    @FloatRange(0.0, 1.0)
    ratingStep: Float = 0.1F,
    starsCount: Int = 5,
    starSize: Dp = 32.dp,
    starSpacing: Dp = 0.dp,
    onRate: ((Float) -> Unit)? = null,
    unratedContent: @Composable BoxScope.(starIndex: Int) -> Unit = {
        RatingBarDefaults.UnratedContent()
    },
    ratedContent: @Composable BoxScope.(starIndex: Int) -> Unit = {
        RatingBarDefaults.RatedContent()
    },
    enableDragging: Boolean = true,
    enableTapping: Boolean = true
) = RatingBarRoot(
    rating = rating,
    modifier = modifier,
    ratingStep = ratingStep,
    starsCount = starsCount,
    starSize = starSize,
    starSpacing = starSpacing,
    onRate = onRate,
    unratedContent = unratedContent,
    ratedContent = ratedContent,
    enableDragging = enableDragging,
    enableTapping = enableTapping
)

/**
 * Default content providers for the RatingBar component.
 */
typealias RatingBarDefaults = RatingBarDefaultsRoot



/**
 * A vertical grid layout that arranges items in rows with a specified number of columns.
 *
 * @param T The type of items in the list
 * @param columns The number of columns per row
 * @param modifier Modifier to be applied to the grid container
 * @param contentPadding Padding to be applied to each grid item
 * @param list The list of items to display in the grid
 * @param content Composable function to render each item
 */
@Composable
fun <T> VerticalGrid(
    columns: Int,
    modifier: Modifier,
    contentPadding: PaddingValues,
    list: List<T>,
    content: @Composable BoxScope.(T) -> Unit
) = VerticalGridRoot(columns, modifier, contentPadding, list, content)

/**
 * A floating action button with text and icon that can expand or collapse.
 * Unlike the standard ExtendedFloatingActionButton, this places the icon on the right side of the text.
 *
 * @param text Composable function to display the text label
 * @param icon Composable function to display the icon
 * @param onClick Callback invoked when the button is clicked
 * @param modifier Modifier to be applied to the button
 * @param expanded Whether the button is expanded to show text, defaults to true
 * @param shape The shape of the button, defaults to extended FAB shape
 * @param containerColor The background color of the button
 * @param contentColor The color of the content (text and icon)
 * @param elevation The elevation levels of the button for different states
 * @param interactionSource The interaction source for handling user interactions
 */
@Composable
fun FlippedExtendedFloatingActionButton(
    text: @Composable () -> Unit,
    icon: @Composable () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    expanded: Boolean = true,
    shape: Shape = FloatingActionButtonDefaults.extendedFabShape,
    containerColor: Color = FloatingActionButtonDefaults.containerColor,
    contentColor: Color = contentColorFor(containerColor),
    elevation: FloatingActionButtonElevation = FloatingActionButtonDefaults.elevation(),
    interactionSource: MutableInteractionSource? = null,
) = FlippedExtendedFloatingActionButtonRoot(
    text = text,
    icon = icon,
    onClick = onClick,
    modifier = modifier,
    expanded = expanded,
    shape = shape,
    containerColor = containerColor,
    contentColor = contentColor,
    elevation = elevation,
    interactionSource = interactionSource
)

/**
 * A composable that displays a horizontal pager of images with loading states and dot indicators.
 *
 * This composable creates a horizontally scrollable image gallery using [HorizontalPager] and loads
 * images using Coil3's [coil3.compose.SubcomposeAsyncImage]. It includes a dot indicator at the bottom to show
 * the current page position. Images are displayed with rounded corners and crop scaling.
 *
 * @param T The type of the item parameter (currently unused in the implementation).
 * @param list Array of image URLs or paths to be displayed in the pager.
 * @param size The size ([DpSize]) to apply to the pager. If width is zero, it will fill max width.
 * @param item An item of type [T] (currently unused, consider removing if not needed).
 * @param background The background color for the container and pager.
 * @param dotColor The color for the dot indicators. Selected dots use this color at full opacity,
 * while unselected dots use 50% opacity.
 * @param loadingAndError Optional composable to display during image loading or error states.
 * Receives a [Boolean] parameter (currently always `true`). If null, default Coil loading/error
 * behavior is used. When provided for loading, a shimmer effect is automatically applied.
 * @param onClick Callback invoked with the index of the clicked image.
 *
 * @see HorizontalPager
 * @see rememberPagerState
 * @see coil3.compose.SubcomposeAsyncImage
 * @see DotsIndicator
 *
 * Example usage:
 * ```
 * ImagesPageView(
 *     list = arrayOf("url1", "url2", "url3"),
 *     size = DpSize(350.dp, 200.dp),
 *     item = myItem,
 *     background = Color.White,
 *     dotColor = Color.Blue,
 *     loadingAndError = { isLoading ->
 *         if (isLoading) {
 *             CircularProgressIndicator()
 *         }
 *     },
 *     onClick = { index ->
 *         // Handle image click
 *         openFullScreen(index)
 *     }
 * )
 * ```
 *
 * Note: Images are loaded using [android.content.Context.imageBuildr] extension function and logged errors
 * are tagged with "ImagesPageView".
 */
@Composable
fun <T> ImagesPageView(
    list: Array<String>,
    size: DpSize,
    item: T,
    background: Color,
    dotColor: Color,
    loadingAndError: @Composable ((Boolean) -> Unit)? = null,
    onClick: (Int) -> Unit
) = ImagesPageViewRoot(
    list = list,
    size = size,
    item = item,
    background = background,
    dotColor = dotColor,
    loadingAndError = loadingAndError,
    onClick = onClick
)

/**
 * A horizontal dots indicator for displaying pagination or selection state.
 *
 * @param totalDots The total number of dots to display
 * @param selectedIndex The index of the currently selected dot (0-based)
 * @param selectedColor The color of the selected dot
 * @param unSelectedColor The color of unselected dots
 */
@Composable
fun DotsIndicator(
    totalDots: Int,
    selectedIndex: Int,
    selectedColor: Color,
    unSelectedColor: Color,
) = DotsIndicatorRoot(totalDots, selectedIndex, selectedColor, unSelectedColor)
