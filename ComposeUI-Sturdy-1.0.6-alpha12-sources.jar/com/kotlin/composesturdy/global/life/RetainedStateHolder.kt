@file:Suppress("unused", "RedundantOverride")

package com.kotlin.composesturdy.global.life

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.retain.retain
import com.kotlin.sturdy.global.life.RetainedStateDelegateRoot
import com.kotlin.sturdy.global.life.RetainedStateHolderRoot
import com.kotlin.sturdy.global.life.collectAsRetainedStateRoot
import com.kotlin.sturdy.global.life.collectInRetainedScopeRoot
import com.kotlin.sturdy.global.life.rememberRetainedRoot
import com.kotlin.sturdy.global.life.retainedStateOfRoot
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

// ─────────────────────────────────────────────────────────────────────────────
// Core: RetainedStateHolder
//
// Base class implementing RetainObserver — the ONLY valid observer interface
// for values passed to retain{}.
//
// !! IMPORTANT: Do NOT implement RememberObserver — it is ILLEGAL on retain{} values
//    and will throw at runtime. !!
//
// Lifecycle callbacks (all final — use the semantic hooks in subclasses):
//   onRetained()          ──► object first captured by retain{}     → onRetainedFirst()
//   onEnteredComposition()──► enters active composition              → onCompositionEntered()
//   onExitedComposition() ──► exits composition (may re-enter later) → onCompositionExited()
//   onRetired()           ──► permanently discarded, never returns   → onRetiredFinal() + scope cancel
//   onUnused()            ──► abandoned before onRetained completed  → onRetiredFinal() + scope cancel
//
// Key behavior difference vs RememberObserver:
//   retainedScope stays ALIVE across onExitedComposition/onEnteredComposition cycles
//   (config changes, back-stack, collapsed content). Cancel ONLY in onRetired/onUnused.
// ─────────────────────────────────────────────────────────────────────────────

abstract class RetainedStateHolder<P>(
    project: P
): RetainedStateHolderRoot<P>(project) {


    /** True while this holder is inside an active composition. */
    val isInComposition: Boolean get() = isInCompositionRoot

    // ── Semantic hooks — override these in subclasses ─────────────────────────

    /**
     * Called once when this holder is first captured by [retain].
     * Start coroutines, collect flows, initialize resources here.
     * Equivalent to ViewModel init {}.
     */
    override fun onRetainedFirst() {
        super.onRetainedFirst()
    }
    override suspend fun onClear() {
        super.onClear()
    }

    /**
     * Called each time the holder enters active composition.
     * May fire more than once (after config change restoration, etc.).
     * Equivalent to onStart().
     */
    override fun onCompositionEntered() {
        super.onCompositionEntered()
    }

    /**
     * Called each time the holder exits composition (but is NOT yet retired).
     * The holder and its [retainedScope] are still alive — do NOT cancel work here.
     * Equivalent to onStop().
     */
    override fun onCompositionExited() {
        super.onCompositionExited()
    }

    /**
     * Called once when this holder is permanently discarded and will never re-enter composition.
     * [retainedScope] is already canceled before this is called.
     * Equivalent to ViewModel.onCleared(). Release non-coroutine resources here.
     */
    override fun onRetiredFinal() {
        super.onRetiredFinal()
    }


    /**
     * Launches a coroutine on the Default dispatcher with exception handling and timeout.
     *
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     * @return Job instance for the launched coroutine
     */
    fun launchBack(
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> Unit
    ): Job = launchBackRoot(failed, block)

    /**
     * Launches a coroutine on the Main dispatcher with exception handling and timeout.
     *
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     * @return Job instance for the launched coroutine
     */
    fun launchMain(
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> Unit
    ): Job = launchMainRoot(failed, block)

    /**
     * Executes a suspend block on the Main dispatcher with exception handling and timeout.
     * Suspends until the block completes.
     *
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     */
    suspend fun withMain(
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> Unit,
    ) = withMainRoot(failed, block)

    /**
     * Executes a suspend block on the Default dispatcher with exception handling and timeout.
     * Suspends until the block completes.
     *
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     */
    suspend fun withDef(
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> Unit,
    ) = withDefRoot(failed, block)

    /**
     * Executes a suspend block on the IO dispatcher with exception handling and timeout.
     * Suspends until the block completes.
     *
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     */
    suspend fun withIO(
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> Unit,
    ) = withIORoot(failed, block)

    /**
     * Executes a suspend block on the Main dispatcher and returns a result.
     * Returns the default value on exception or timeout.
     *
     * @param D The return type
     * @param def Default value to return on exception or timeout
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     * @return The result of the block or the default value on error
     */
    suspend fun <D> withMain(
        def: D,
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> D,
    ): D = withMainRoot(def, failed, block)

    /**
     * Executes a suspend block on the Default dispatcher and returns a result.
     * Returns the default value on exception or timeout.
     *
     * @param D The return type
     * @param def Default value to return on exception or timeout
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     * @return The result of the block or the default value on error
     */
    suspend fun <D> withDefault(
        def: D,
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> D,
    ): D = withDefaultRoot(def, failed, block)

    /**
     * Executes a suspend block on the IO dispatcher and returns a result.
     * Returns the default value on exception or timeout.
     *
     * @param D The return type
     * @param def Default value to return on exception or timeout
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     * @return The result of the block or the default value on error
     */
    suspend fun <D> withIODefault(
        def: D,
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> D,
    ): D = withIODefaultRoot(def, failed, block)

    /**
     * Checks if the Context is null and cancels the current scope if it is.
     * Useful for preventing operations when Context becomes invalid.
     */
    suspend fun Context?.nullChecker() = nullCheckerRoot()


    /**
     * Safely cancels the current coroutine scope and all its children.
     * Handles cancellation exceptions internally.
     */
    fun CoroutineScope.cancelScope() = cancelScopeRoot()
}

// ─────────────────────────────────────────────────────────────────────────────
// Composable: rememberRetained
//
// Wraps retain{} — NOT remember{} — so the holder survives:
//   • Configuration changes (rotation, locale, font-size)
//   • Back-stack removal with potential restoration
//   • Activity recreation
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Creates and retains a [RetainedStateHolder] for the current composition using [retain].
 *
 * ```kotlin
 * val holder = rememberRetained { ProfileHolder(repository) }
 * ```
 *
 * @param keys    Changing any key retires the existing holder and creates a new one.
 * @param factory Lambda producing the [T] instance.
 */
@Composable
inline fun <reified P, reified T: RetainedStateHolder<P>> rememberRetained(
    vararg keys: Any?,
    crossinline factory: () -> T
): T = rememberRetainedRoot(*keys) { factory() }

// ─────────────────────────────────────────────────────────────────────────────
// State delegate: retainedStateOf
//
// Property delegate wrapping MutableState<T> for use inside RetainedStateHolder.
// Compose reads are tracked automatically — no collectAsState() needed.
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Property delegate wrapping [mutableStateOf] for use inside [RetainedStateHolder].
 * Triggers recomposition on write.
 *
 * ```kotlin
 * class ProfileHolder : RetainedStateHolder() {
 *     var uiState by retainedStateOf<UiState<User>>(UiState.Idle)
 *         private set
 * }
 * ```
 */
fun <T, P> retainedStateOf(initialValue: T): RetainedStateDelegateRoot<T, P> = retainedStateOfRoot(initialValue)

// ─────────────────────────────────────────────────────────────────────────────
// Flow helpers
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Collects this [Flow] in the holder's retained scope.
 * Call from [RetainedStateHolder.onRetainedFirst] — survives config changes.
 *
 * ```kotlin
 * override fun onRetainedFirst() {
 *     repository.stream.collectInRetainedScope(this) { value = it }
 * }
 * ```
 */
fun <T, P> Flow<T>.collectInRetainedScope(
    holder: RetainedStateHolder<P>,
    onEach: (T) -> Unit
): Job = collectInRetainedScopeRoot(holder, onEach)

/**
 * Collects a [StateFlow] as Compose [State], scoped to the holder's retained scope.
 *
 * ```kotlin
 * val items by externalFlow.collectAsRetainedState(holder.retainedScope)
 * ```
 */
@Composable
fun <T> StateFlow<T>.collectAsRetainedState(scope: CoroutineScope): State<T> = collectAsRetainedStateRoot(scope)

// ─────────────────────────────────────────────────────────────────────────────
// UiState — sealed async result wrapper
// ─────────────────────────────────────────────────────────────────────────────

sealed class UiState<out T> {
    data object Idle    : UiState<Nothing>()
    data object Loading : UiState<Nothing>()
    data class  Success<T>(val data: T)                                  : UiState<T>()
    data class  Error(val message: String, val cause: Throwable? = null) : UiState<Nothing>()

    val isLoading:   Boolean  get() = this is Loading
    val isSuccess:   Boolean  get() = this is Success
    val isError:     Boolean  get() = this is Error
    val dataOrNull:  T?       get() = (this as? Success)?.data
    val errorOrNull: String?  get() = (this as? Error)?.message
}

/**
 * Wraps a suspending [block] as [UiState], auto-mapping exceptions to [UiState.Error].
 * Always re-throws [CancellationException] — never swallows scope cancellation.
 *
 * ```kotlin
 * fun load(id: String) = launch {
 *     uiState = UiState.Loading
 *     uiState = runAsUiState { repository.get(id) }
 * }
 * ```
 */
suspend fun <T> runAsUiState(block: suspend () -> T): UiState<T> = try {
    UiState.Success(block())
} catch (e: CancellationException) {
    throw e
} catch (e: Exception) {
    UiState.Error(e.message ?: "Unknown error", e)
}
