@file:Suppress("unused")

package com.kotlin.composesturdy.global.life

import android.content.Context
import com.kotlin.sturdy.global.life.BaseViewModelRoot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel

/**
 * Base ViewModel with built-in coroutine management and exception handling utilities.
 * Provides convenient methods for launching coroutines on different dispatchers with automatic error handling.
 *
 * @param T The type of project/dependency injected into the ViewModel
 * @param project The project or dependency instance used by this ViewModel
 *
 * @see [RetainedStateHolder] Better if you migrate to RetainObserver, but this is still useful for non-UI related ViewModels or when you want to manage state without Compose.
 */
abstract class BaseViewModel<T>(
    project: T
) : BaseViewModelRoot<T>(project) {

    /**
     * Launches a coroutine on the Default dispatcher with exception handling and timeout.
     *
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     * @return Job instance for the launched coroutine
     */
    fun launchBack(
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> Unit
    ): Job = launchBackRoot(failed, block)

    /**
     * Launches a coroutine on the Main dispatcher with exception handling and timeout.
     *
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     * @return Job instance for the launched coroutine
     */
    fun launchMain(
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> Unit
    ): Job = launchMainRoot(failed, block)

    /**
     * Executes a suspend block on the Main dispatcher with exception handling and timeout.
     * Suspends until the block completes.
     *
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     */
    suspend fun withMain(
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> Unit,
    ) = withMainRoot(failed, block)

    /**
     * Executes a suspend block on the Default dispatcher with exception handling and timeout.
     * Suspends until the block completes.
     *
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     */
    suspend fun withDef(
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> Unit,
    ) = withDefRoot(failed, block)

    /**
     * Executes a suspend block on the IO dispatcher with exception handling and timeout.
     * Suspends until the block completes.
     *
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     */
    suspend fun withIO(
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> Unit,
    ) = withIORoot(failed, block)

    /**
     * Executes a suspend block on the Main dispatcher and returns a result.
     * Returns the default value on exception or timeout.
     *
     * @param D The return type
     * @param def Default value to return on exception or timeout
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     * @return The result of the block or the default value on error
     */
    suspend fun <D> withMain(
        def: D,
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> D,
    ): D = withMainRoot(def, failed, block)

    /**
     * Executes a suspend block on the Default dispatcher and returns a result.
     * Returns the default value on exception or timeout.
     *
     * @param D The return type
     * @param def Default value to return on exception or timeout
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     * @return The result of the block or the default value on error
     */
    suspend fun <D> withDefault(
        def: D,
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> D,
    ): D = withDefaultRoot(def, failed, block)

    /**
     * Executes a suspend block on the IO dispatcher and returns a result.
     * Returns the default value on exception or timeout.
     *
     * @param D The return type
     * @param def Default value to return on exception or timeout
     * @param failed Callback invoked with error message on exception
     * @param block The suspend function to execute
     * @return The result of the block or the default value on error
     */
    suspend fun <D> withIODefault(
        def: D,
        failed: (String) -> Unit = {},
        block: suspend CoroutineScope.() -> D,
    ): D = withIODefaultRoot(def, failed, block)

    /**
     * Checks if the Context is null and cancels the current scope if it is.
     * Useful for preventing operations when Context becomes invalid.
     */
    suspend fun Context?.nullChecker() = nullCheckerRoot()

    /**
     * Safely cancels the current coroutine scope and all its children.
     * Handles cancellation exceptions internally.
     */
    fun CoroutineScope.cancelScope() = cancelScopeRoot()

    override fun onCleared() {
        cancel()
        super.onCleared()
    }
}